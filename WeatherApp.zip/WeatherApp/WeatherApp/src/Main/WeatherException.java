package Main;


/**
 * Temel hava durumu exception sınıfı
 */
public class WeatherException extends Exception {
    public WeatherException(String message) {
        super(message);
    }

    public WeatherException(String message, Throwable cause) {
        super(message, cause);
    }
}

/**
 * Geçersiz şehir adı girildiğinde fırlatılır
 */
class InvalidCityNameException extends WeatherException {
    public InvalidCityNameException(String cityName) {
        super("Geçersiz şehir adı: '" + cityName + "'. Lütfen doğru bir şehir adı girin!");
    }
}

/**
 * Hava durumu verisi bulunamadığında fırlatılır
 */
class WeatherDataNotFoundException extends WeatherException {
    public WeatherDataNotFoundException(String city) {
        super("'" + city + "' şehri için hava durumu verisi bulunamadı!");
    }

    public WeatherDataNotFoundException(String city, String reason) {
        super("'" + city + "' şehri için hava durumu verisi bulunamadı: " + reason);
    }
}

/**
 * Graph oluşturma ve işleme hataları
 */
class GraphOperationException extends WeatherException {
    public GraphOperationException(String operation) {
        super("Graph " + operation + " işlemi başarısız!");
    }

    public GraphOperationException(String operation, String reason) {
        super("Graph " + operation + " işlemi başarısız: " + reason);
    }
}

/**
 * UI güncelleme ve etkileşim hataları
 */
class UIOperationException extends WeatherException {
    public UIOperationException(String component, String operation) {
        super(component + " bileşeninde " + operation + " işlemi başarısız!");
    }

    public UIOperationException(String component, String operation, String reason) {
        super(component + " bileşeninde " + operation + " işlemi başarısız: " + reason);
    }
}

/**
 * Veri işleme ve dönüştürme hataları
 */
class DataProcessingException extends WeatherException {
    public DataProcessingException(String dataType, String operation) {
        super(dataType + " verisi " + operation + " işlemi başarısız!");
    }

    public DataProcessingException(String dataType, String operation, String reason) {
        super(dataType + " verisi " + operation + " işlemi başarısız: " + reason);
    }
}

/**
 * Hava durumu servisi bağlantı hatası
 */
class WeatherServiceException extends WeatherException {
    public WeatherServiceException(String message) {
        super("Hava durumu servisi hatası: " + message);
    }

    public WeatherServiceException(String operation, String reason) {
        super("Hava durumu servisi " + operation + " işlemi başarısız: " + reason);
    }
}