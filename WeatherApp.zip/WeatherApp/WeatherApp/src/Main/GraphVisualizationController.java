package Main;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class GraphVisualizationController {

    @FXML private Label cityLabel;
    @FXML private Label statsLabel;
    @FXML private Label algorithmLabel;
    @FXML private Pane graphPane;

    private String city;
    private MyGraph<District> weatherGraph;
    private final MyLinkedList<DistrictNodePair> nodePositions = new MyLinkedList<>();
    private boolean isLoading = false;

    private static class DistrictNodePair {
        District district;
        GraphNode node;

        DistrictNodePair(District district, GraphNode node) {
            this.district = district;
            this.node = node;
        }
    }

    private static class GraphNode {
        double x, y;
        Circle circle;
        Text label;

        GraphNode(double x, double y) {
            this.x = x;
            this.y = y;
        }
    }

    public void setCity(String city) {
        try {
            if (city == null || city.trim().isEmpty()) {
                throw new InvalidCityNameException("Boş şehir adı");
            }
            if (city.trim().length() < 2) {
                throw new InvalidCityNameException(city);
            }

            this.city = city;
            cityLabel.setText(city + " - Graph Ağ Haritası");
            loadGraphVisualization();

        } catch (WeatherException e) {
            showErrorAlert("Şehir Hatası", e.getMessage());
        }
    }

    private void loadGraphVisualization() {
        if (isLoading) {
            showErrorAlert("Uyarı", "Graph yükleme devam ediyor");
            return;
        }

        isLoading = true;
        algorithmLabel.setText("🔄 Graph ağı oluşturuluyor...");

        new Thread(() -> {
            try {
                weatherGraph = createWeatherGraph();

                Platform.runLater(() -> {
                    try {
                        drawGraph();
                        updateStatistics();
                        isLoading = false;
                    } catch (WeatherException e) {
                        showErrorAlert("Görselleştirme Hatası", e.getMessage());
                        isLoading = false;
                    }
                });

            } catch (WeatherException e) {
                Platform.runLater(() -> {
                    showErrorAlert("Graph Hatası", e.getMessage());
                    isLoading = false;
                });
            }
        }).start();
    }

    private MyGraph<District> createWeatherGraph() throws WeatherException {
        try {
            MyGraph<District> graph = WeatherGraphService.createWeatherGraph(city);
            if (graph == null) {
                throw new GraphOperationException("oluşturma", city + " için graph servisi null döndürdü");
            }
            return graph;
        } catch (Exception e) {
            throw new GraphOperationException("oluşturma", city + " için hata: " + e.getMessage());
        }
    }

    private void drawGraph() throws WeatherException {
        try {
            if (graphPane == null) {
                throw new UIOperationException("GraphPane", "doğrulama", "Null referans");
            }

            graphPane.getChildren().clear();
            nodePositions.clear();

            MyLinkedList<District> districts = getDistrictList();
            if (districts.isEmpty()) {
                throw new DataProcessingException("District listesi", "alma", "Boş district listesi");
            }

            calculateNodePositions(districts);
            drawEdges();
            drawNodes();

        } catch (Exception e) {
            throw new UIOperationException("Graph", "çizim", e.getMessage());
        }
    }

    private MyLinkedList<District> getDistrictList() throws WeatherException {
        if (weatherGraph == null) {
            throw new DataProcessingException("Graph", "veri alma", "Graph null");
        }

        MyLinkedList<District> districts = new MyLinkedList<>();
        for (District district : weatherGraph.getAllVertices()) {
            if (district != null) {
                districts.add(district);
            }
        }
        return districts;
    }

    private void calculateNodePositions(MyLinkedList<District> districts) throws WeatherException {
        double width = graphPane.getPrefWidth();
        double height = graphPane.getPrefHeight();

        if (width <= 0 || height <= 0) {
            throw new DataProcessingException("Grafik boyutları", "doğrulama", "Geçersiz boyutlar: " + width + "x" + height);
        }

        double centerX = width / 2;
        double centerY = height / 2;
        double margin = 100;
        double radius = Math.min(width, height) / 2 - margin;

        if (radius <= 0) {
            throw new DataProcessingException("Radius", "hesaplama", "Grafik alanı çok küçük");
        }

        District center = findCenterDistrict(districts);
        nodePositions.add(new DistrictNodePair(center, new GraphNode(centerX, centerY)));

        MyLinkedList<District> otherDistricts = getOtherDistricts(districts, center);
        placePeripheralNodes(otherDistricts, centerX, centerY, radius, width, height);
    }

    private District findCenterDistrict(MyLinkedList<District> districts) throws WeatherException {
        for (District d : districts) {
            if (d != null && d.getName() != null && d.getName().contains("Merkez")) {
                return d;
            }
        }

        if (!districts.isEmpty()) {
            return districts.get(0);
        }

        throw new DataProcessingException("Merkez district", "bulma", "Merkez district bulunamadı");
    }

    private MyLinkedList<District> getOtherDistricts(MyLinkedList<District> districts, District center) {
        MyLinkedList<District> otherDistricts = new MyLinkedList<>();
        for (District d : districts) {
            if (d != null && !d.equals(center)) {
                otherDistricts.add(d);
            }
        }
        return otherDistricts;
    }

    private void placePeripheralNodes(MyLinkedList<District> otherDistricts, double centerX, double centerY,
                                      double radius, double width, double height) throws WeatherException {
        if (otherDistricts.isEmpty()) return;

        double adjustedRadius = radius;
        if (otherDistricts.size() > 8) {
            adjustedRadius = radius * 1.2;
        }

        double angleStep = 2 * Math.PI / otherDistricts.size();

        for (int i = 0; i < otherDistricts.size(); i++) {
            double angle = i * angleStep - Math.PI/2;
            double x = centerX + adjustedRadius * Math.cos(angle);
            double y = centerY + adjustedRadius * Math.sin(angle);

            x = Math.max(50, Math.min(width - 50, x));
            y = Math.max(50, Math.min(height - 50, y));

            GraphNode node = new GraphNode(x, y);
            nodePositions.add(new DistrictNodePair(otherDistricts.get(i), node));
        }
    }

    private void drawEdges() throws WeatherException {
        try {
            for (District district : weatherGraph.getAllVertices()) {
                if (district == null) continue;

                GraphNode sourceNode = getNodeForDistrict(district);
                if (sourceNode == null) continue;

                for (MyGraph.Edge<District> edge : weatherGraph.getNeighbors(district)) {
                    if (edge == null || edge.getDestination() == null) continue;

                    District target = edge.getDestination();
                    GraphNode targetNode = getNodeForDistrict(target);

                    if (targetNode != null) {
                        drawSingleEdge(sourceNode, targetNode, edge.getWeight());
                    }
                }
            }
        } catch (Exception e) {
            throw new UIOperationException("Kenarlar", "çizim", e.getMessage());
        }
    }

    private void drawSingleEdge(GraphNode sourceNode, GraphNode targetNode, double tempDiff) throws WeatherException {
        try {
            Line line = new Line(sourceNode.x, sourceNode.y, targetNode.x, targetNode.y);

            if (tempDiff < 1.0) {
                line.setStroke(Color.web("#4CAF50"));
                line.setStrokeWidth(2);
            } else if (tempDiff < 2.0) {
                line.setStroke(Color.web("#FF9800"));
                line.setStrokeWidth(2.5);
            } else {
                line.setStroke(Color.web("#F44336"));
                line.setStrokeWidth(3);
            }

            line.setOpacity(0.6);
            graphPane.getChildren().add(line);

            if (tempDiff > 0.5) {
                addEdgeLabel(sourceNode, targetNode, tempDiff);
            }

        } catch (Exception e) {
            throw new UIOperationException("Kenar", "çizim", e.getMessage());
        }
    }

    private void addEdgeLabel(GraphNode sourceNode, GraphNode targetNode, double tempDiff) throws WeatherException {
        try {
            double midX = (sourceNode.x + targetNode.x) / 2;
            double midY = (sourceNode.y + targetNode.y) / 2;

            Text edgeLabel = new Text(midX, midY, String.format("%.1f°", tempDiff));
            edgeLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 9));
            edgeLabel.setFill(Color.web("#1976D2"));
            edgeLabel.setOpacity(0.7);
            edgeLabel.setX(edgeLabel.getX() - edgeLabel.getBoundsInLocal().getWidth() / 2);

            graphPane.getChildren().add(edgeLabel);
        } catch (Exception e) {
            throw new UIOperationException("Kenar etiketi", "ekleme", e.getMessage());
        }
    }

    private void drawNodes() throws WeatherException {
        try {
            for (DistrictNodePair pair : nodePositions) {
                if (pair == null || pair.district == null || pair.node == null) continue;

                drawSingleNode(pair.district, pair.node);
            }
        } catch (Exception e) {
            throw new UIOperationException("Düğümler", "çizim", e.getMessage());
        }
    }

    private void drawSingleNode(District district, GraphNode node) throws WeatherException {
        try {
            double nodeRadius = district.getName().contains("Merkez") ? 30 : 20;
            Circle circle = new Circle(node.x, node.y, nodeRadius);

            Color nodeColor = getNodeColor(district.getTemperature());
            circle.setFill(nodeColor);

            setupNodeStyle(circle, district);

            node.circle = circle;
            graphPane.getChildren().add(circle);

            addNodeLabel(district, node, nodeRadius);

            setupNodeInteraction(circle, district);

        } catch (Exception e) {
            throw new UIOperationException("Düğüm", "çizim", e.getMessage());
        }
    }

    private Color getNodeColor(double temp) {
        if (temp < 10) return Color.web("#E3F2FD");
        else if (temp < 15) return Color.web("#BBDEFB");
        else if (temp < 20) return Color.web("#C8E6C9");
        else if (temp < 25) return Color.web("#FFF9C4");
        else if (temp < 30) return Color.web("#FFCC80");
        else return Color.web("#FFAB91");
    }

    private void setupNodeStyle(Circle circle, District district) {
        if (district.getName().contains("Merkez")) {
            circle.setFill(Color.web("#FFD700"));
            circle.setStroke(Color.web("#B8860B"));
            circle.setStrokeWidth(3);
        } else {
            circle.setStroke(Color.web("#1976D2"));
            circle.setStrokeWidth(2);
        }
        circle.setOpacity(0.9);
    }

    private void addNodeLabel(District district, GraphNode node, double nodeRadius) throws WeatherException {
        try {
            String shortName = district.getName().replace(city + " ", "");
            if (shortName.length() > 10) {
                shortName = shortName.substring(0, 8) + "..";
            }

            String labelText = shortName + "\n" + String.format("%.1f°C", district.getTemperature());
            Text label = new Text(node.x, node.y + nodeRadius + 25, labelText);
            label.setFont(Font.font("Arial", FontWeight.BOLD, 10));
            label.setFill(Color.web("#1565C0"));
            label.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
            label.setX(label.getX() - label.getBoundsInLocal().getWidth() / 2);

            node.label = label;
            graphPane.getChildren().add(label);
        } catch (Exception e) {
            throw new UIOperationException("Düğüm etiketi", "ekleme", e.getMessage());
        }
    }

    private void setupNodeInteraction(Circle circle, District district) {
        circle.setOnMouseEntered(e -> {
            circle.setScaleX(1.1);
            circle.setScaleY(1.1);
            circle.setOpacity(1.0);
        });

        circle.setOnMouseExited(e -> {
            circle.setScaleX(1.0);
            circle.setScaleY(1.0);
            circle.setOpacity(0.9);
        });

        circle.setOnMouseClicked(e -> {
            try {
                showDistrictInfo(district);
            } catch (Exception ex) {
                showErrorAlert("Etkileşim Hatası", "District bilgisi gösterilemedi: " + ex.getMessage());
            }
        });
    }

    private void showDistrictInfo(District district) throws WeatherException {
        try {
            if (algorithmLabel == null) {
                throw new UIOperationException("AlgorithmLabel", "district info güncelleme", "Label referansı null");
            }

            String info = String.format("🎯 Seçilen: %s | %.1f°C | %s",
                    district.getName().replace(city + " ", ""),
                    district.getTemperature(),
                    district.getDescription());

            algorithmLabel.setText(info);

        } catch (Exception e) {
            throw new UIOperationException("District info", "gösterme", e.getMessage());
        }
    }

    private GraphNode getNodeForDistrict(District district) {
        for (DistrictNodePair pair : nodePositions) {
            if (pair != null && pair.district != null && pair.district.equals(district)) {
                return pair.node;
            }
        }
        return null;
    }

    private void updateStatistics() throws WeatherException {
        try {
            if (weatherGraph == null) {
                throw new DataProcessingException("İstatistik", "güncelleme", "Graph null");
            }

            String stats = WeatherGraphService.getGraphStatistics(weatherGraph);

            if (statsLabel != null) {
                statsLabel.setText(stats.replace("\n", " | "));
            }

            if (algorithmLabel != null) {
                algorithmLabel.setText("✅ Graph ağı hazır - Düğümlere tıklayarak detay görün");
            }

        } catch (Exception e) {
            throw new UIOperationException("İstatistikler", "güncelleme", e.getMessage());
        }
    }

    @FXML
    private void onRefresh() {
        loadGraphVisualization();
    }

    @FXML
    private void onAnalyzeTemperatures() {
        try {
            if (weatherGraph == null) {
                throw new DataProcessingException("Sıcaklık analizi", "başlatma", "Graph null");
            }

            District[] extremes = findTemperatureExtremes();
            displayTemperatureAnalysis(extremes[0], extremes[1]);
            highlightExtremeTemperatures(extremes[0], extremes[1]);

        } catch (WeatherException e) {
            showErrorAlert("Analiz Hatası", e.getMessage());
        }
    }

    private District[] findTemperatureExtremes() throws WeatherException {
        District hottest = null;
        District coldest = null;
        double maxTemp = Double.MIN_VALUE;
        double minTemp = Double.MAX_VALUE;

        for (District district : weatherGraph.getAllVertices()) {
            if (district == null) continue;

            double temp = district.getTemperature();
            if (Double.isNaN(temp) || Double.isInfinite(temp)) continue;

            if (temp > maxTemp) {
                maxTemp = temp;
                hottest = district;
            }
            if (temp < minTemp) {
                minTemp = temp;
                coldest = district;
            }
        }

        if (hottest == null || coldest == null) {
            throw new DataProcessingException("Sıcaklık uç değerleri", "bulma", "Geçerli sıcaklık verisi bulunamadı");
        }

        return new District[]{hottest, coldest};
    }

    private void displayTemperatureAnalysis(District hottest, District coldest) throws WeatherException {
        try {
            String hottestName = hottest.getName().replace(city + " ", "");
            String coldestName = coldest.getName().replace(city + " ", "");

            if (hottestName.length() > 10) hottestName = hottestName.substring(0, 8) + "..";
            if (coldestName.length() > 10) coldestName = coldestName.substring(0, 8) + "..";

            double tempDiff = hottest.getTemperature() - coldest.getTemperature();

            String analysisText = String.format("🌡️ En sıcak: %s (%.1f°C) | En soğuk: %s (%.1f°C) | Fark: %.1f°C",
                    hottestName, hottest.getTemperature(),
                    coldestName, coldest.getTemperature(),
                    tempDiff);

            if (algorithmLabel != null) {
                algorithmLabel.setText(analysisText);
            } else {
                throw new UIOperationException("AlgorithmLabel", "sıcaklık analizi güncelleme", "Label referansı null");
            }

        } catch (Exception e) {
            throw new UIOperationException("Sıcaklık analizi", "görüntüleme", e.getMessage());
        }
    }

    private void highlightExtremeTemperatures(District hottest, District coldest) throws WeatherException {
        try {
            resetNodeStyles();

            GraphNode hottestNode = getNodeForDistrict(hottest);
            if (hottestNode != null && hottestNode.circle != null) {
                hottestNode.circle.setStroke(Color.web("#FF0000"));
                hottestNode.circle.setStrokeWidth(4);
                hottestNode.circle.setScaleX(1.2);
                hottestNode.circle.setScaleY(1.2);
            }

            GraphNode coldestNode = getNodeForDistrict(coldest);
            if (coldestNode != null && coldestNode.circle != null) {
                coldestNode.circle.setStroke(Color.web("#0000FF"));
                coldestNode.circle.setStrokeWidth(4);
                coldestNode.circle.setScaleX(1.2);
                coldestNode.circle.setScaleY(1.2);
            }

        } catch (Exception e) {
            throw new UIOperationException("Sıcaklık vurgulama", "işlem", e.getMessage());
        }
    }

    private void resetNodeStyles() throws WeatherException {
        try {
            for (DistrictNodePair pair : nodePositions) {
                if (pair == null || pair.district == null || pair.node == null || pair.node.circle == null) {
                    continue;
                }

                District district = pair.district;
                GraphNode node = pair.node;

                if (district.getName().contains("Merkez")) {
                    node.circle.setStroke(Color.web("#B8860B"));
                    node.circle.setStrokeWidth(3);
                } else {
                    node.circle.setStroke(Color.web("#1976D2"));
                    node.circle.setStrokeWidth(2);
                }
                node.circle.setScaleX(1.0);
                node.circle.setScaleY(1.0);
            }
        } catch (Exception e) {
            throw new UIOperationException("Düğüm stilleri", "sıfırlama", e.getMessage());
        }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void onBack() {
        if (isLoading) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Uyarı");
            alert.setContentText("Graph işlemleri devam ediyor. Lütfen bekleyin...");
            alert.showAndWait();
            return;
        }

        try {
            HelloFX.showMainScreen();
        } catch (Exception e) {
            UIOperationException navError = new UIOperationException("Ana ekran", "geçiş", e.getMessage());
            showErrorAlert("Navigasyon Hatası", navError.getMessage());
        }
    }

    public boolean isCurrentlyLoading() {
        return isLoading;
    }

    public MyLinkedList<DistrictNodePair> getNodePositions() {
        return nodePositions;
    }

    public MyGraph<District> getWeatherGraph() {
        return weatherGraph;
    }
}