package Main;

public class Weather {
    private double temperature;
    private String description;
    private String icon;

    public Weather(double temperature, String description, String icon) {
        this.temperature = temperature;
        this.description = description;
        this.icon = icon;
    }

    public double getTemperature() {
        return temperature;
    }

    public String getDescription() {
        return description;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    @Override
    public String toString() {
        return String.format("%s\nSıcaklık: %.1f°C", description, temperature);
    }
}
