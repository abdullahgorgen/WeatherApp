package Main;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    private static final MyLinkedList<User> users = new MyLinkedList<>();
    private final MyBST<String, Integer> failedAttempts = new MyBST<>();
    private final MyBST<String, LocalDateTime> lockTimes = new MyBST<>();

    private static final int MAX_FAILED_ATTEMPTS = 3;
    private static final int LOCK_DURATION_SECONDS = 10;

    static {
        try {
            initializeDefaultUsers();
        } catch (Exception e) {
            System.err.println("Varsayılan kullanıcılar oluşturulamadı: " + e.getMessage());
        }
    }

    private static void initializeDefaultUsers() {
        try {
            User adminUser = new User("admin", "1234", true);
            adminUser.setRegistrationDate(LocalDateTime.now());
            users.add(adminUser);

            User testUser = new User("test", "test", false);
            testUser.setRegistrationDate(LocalDateTime.now());
            users.add(testUser);

        } catch (Exception e) {
            System.err.println("Varsayılan kullanıcı oluşturma hatası: " + e.getMessage());
        }
    }

    public static MyLinkedList<User> getUsersList() {
        return users;
    }

    @FXML
    private void onLogin() {
        try {
            String username = getUsernameInput();
            String password = getPasswordInput();

            performSecurityChecks(username);

            User user = authenticateUser(username, password);

            handleSuccessfulLogin(user);

        } catch (WeatherException e) {
            handleLoginError(e.getMessage());
        } catch (Exception e) {
            handleLoginError("Beklenmeyen giriş hatası: " + e.getMessage());
        }
    }

    private String getUsernameInput() throws WeatherException {
        try {
            if (usernameField == null) {
                throw new UIOperationException("Username field", "doğrulama", "Null referans");
            }

            String username = usernameField.getText();
            if (username == null) username = "";
            username = username.trim();

            if (username.isEmpty()) {
                throw new DataProcessingException("Kullanıcı adı", "doğrulama", "Boş olamaz");
            }
            if (username.length() < 2) {
                throw new DataProcessingException("Kullanıcı adı", "doğrulama", "En az 2 karakter olmalı");
            }
            if (username.length() > 50) {
                throw new DataProcessingException("Kullanıcı adı", "doğrulama", "En fazla 50 karakter olabilir");
            }
            if (!username.matches("^[a-zA-Z0-9_-]+$")) {
                throw new DataProcessingException("Kullanıcı adı", "doğrulama", "Sadece harf, rakam, _ ve - karakterleri içerebilir");
            }

            return username;

        } catch (Exception e) {
            throw new DataProcessingException("Kullanıcı adı", "doğrulama", e.getMessage());
        }
    }

    private String getPasswordInput() throws WeatherException {
        try {
            if (passwordField == null) {
                throw new UIOperationException("Password field", "doğrulama", "Null referans");
            }

            String password = passwordField.getText();
            if (password == null) password = "";
            password = password.trim();

            if (password.isEmpty()) {
                throw new DataProcessingException("Şifre", "doğrulama", "Boş olamaz");
            }
            if (password.length() < 3) {
                throw new DataProcessingException("Şifre", "doğrulama", "En az 3 karakter olmalı");
            }
            if (password.length() > 100) {
                throw new DataProcessingException("Şifre", "doğrulama", "En fazla 100 karakter olabilir");
            }

            return password;

        } catch (Exception e) {
            throw new DataProcessingException("Şifre", "doğrulama", e.getMessage());
        }
    }

    private void performSecurityChecks(String username) throws WeatherException {
        try {
            if (isUserTimeLocked(username)) {
                LocalDateTime lockTime = lockTimes.get(username);
                long remainingSeconds = LOCK_DURATION_SECONDS -
                        ChronoUnit.SECONDS.between(lockTime, LocalDateTime.now());

                throw new WeatherServiceException("güvenlik kontrolü",
                        "Hesap kilitli. " + remainingSeconds + " saniye sonra tekrar deneyin.");
            }

            clearExpiredLock(username);

        } catch (WeatherException e) {
            throw e;
        } catch (Exception e) {
            throw new WeatherServiceException("güvenlik kontrolü", e.getMessage());
        }
    }

    private boolean isUserTimeLocked(String username) {
        try {
            LocalDateTime lockTime = lockTimes.get(username);
            if (lockTime == null) {
                return false;
            }

            long secondsPassed = ChronoUnit.SECONDS.between(lockTime, LocalDateTime.now());
            return secondsPassed < LOCK_DURATION_SECONDS;

        } catch (Exception e) {
            return false;
        }
    }

    private void clearExpiredLock(String username) {
        try {
            LocalDateTime lockTime = lockTimes.get(username);
            if (lockTime != null) {
                long secondsPassed = ChronoUnit.SECONDS.between(lockTime, LocalDateTime.now());
                if (secondsPassed >= LOCK_DURATION_SECONDS) {
                    lockTimes.remove(username);
                    failedAttempts.remove(username);
                }
            }
        } catch (Exception e) {
            System.err.println("Kilitleme temizlenemedi: " + e.getMessage());
        }
    }

    private User authenticateUser(String username, String password) throws WeatherException {
        try {
            User user = findUserByUsername(username);

            if (user == null) {
                recordFailedAttempt(username);
                throw new WeatherDataNotFoundException("Kullanıcı", "Kullanıcı adı bulunamadı");
            }

            if (!verifyPassword(user, password)) {
                recordFailedAttempt(username);
                throw new WeatherServiceException("şifre doğrulama", "Şifre hatalı");
            }

            if (!user.isActive()) {
                recordFailedAttempt(username);
                throw new WeatherServiceException("kullanıcı durumu", "Hesap pasif durumda");
            }

            resetFailedAttempts(username);

            user.setLastLogin(LocalDateTime.now());

            return user;

        } catch (WeatherException e) {
            throw e;
        } catch (Exception e) {
            throw new WeatherServiceException("kullanıcı doğrulama", e.getMessage());
        }
    }

    private User findUserByUsername(String username) throws WeatherException {
        try {
            if (users == null || users.isEmpty()) {
                throw new DataProcessingException("Kullanıcı listesi", "arama", "Kullanıcı listesi boş");
            }

            for (User user : users) {
                if (user != null && user.getUsername() != null &&
                        user.getUsername().equals(username)) {
                    return user;
                }
            }

            return null;

        } catch (Exception e) {
            throw new DataProcessingException("Kullanıcı", "arama", e.getMessage());
        }
    }

    private boolean verifyPassword(User user, String password) throws WeatherException {
        try {
            if (user == null || user.getPassword() == null) {
                throw new DataProcessingException("Şifre", "doğrulama", "Kullanıcı veya şifre null");
            }

            return user.getPassword().equals(password);

        } catch (Exception e) {
            throw new DataProcessingException("Şifre", "doğrulama", e.getMessage());
        }
    }

    private void recordFailedAttempt(String username) {
        try {
            Integer currentAttempts = failedAttempts.get(username);
            if (currentAttempts == null) {
                currentAttempts = 0;
            }
            currentAttempts++;
            failedAttempts.put(username, currentAttempts);

            if (currentAttempts >= MAX_FAILED_ATTEMPTS) {
                lockTimes.put(username, LocalDateTime.now());
                System.out.println("Kullanıcı " + username + " hesabı " + LOCK_DURATION_SECONDS + " saniye kilitlendi.");
            }

        } catch (Exception e) {
            System.err.println("Başarısız giriş kaydedilemedi: " + e.getMessage());
        }
    }

    private void resetFailedAttempts(String username) {
        try {
            failedAttempts.remove(username);
            lockTimes.remove(username);
        } catch (Exception e) {
            System.err.println("Başarılı giriş kaydedilemedi: " + e.getMessage());
        }
    }

    private void handleSuccessfulLogin(User user) throws WeatherException {
        try {
            showSuccessMessage("Giriş başarılı! Hoş geldiniz " + user.getUsername());

            HelloFX.setCurrentUser(user);

            HelloFX.showMainScreen();

        } catch (Exception e) {
            throw new UIOperationException("Ana ekran", "geçiş", e.getMessage());
        }
    }

    @FXML
    private void onRegister() {
        try {
            HelloFX.showRegisterScreen();
        } catch (Exception e) {
            handleLoginError("Kayıt ekranına geçiş hatası: " + e.getMessage());
        }
    }

    private void handleLoginError(String errorMessage) {
        try {
            showErrorMessage(errorMessage);
        } catch (Exception e) {
            System.err.println("Hata gösterilemedi: " + errorMessage);
        }
    }

    private void showErrorMessage(String message) throws WeatherException {
        try {
            if (errorLabel == null) {
                throw new UIOperationException("Error label", "güncelleme", "Null referans");
            }

            errorLabel.setText("❌ " + message);
            errorLabel.setTextFill(Color.web("#F44336"));
            errorLabel.setVisible(true);

            startErrorClearTimer();

        } catch (Exception e) {
            throw new UIOperationException("Error label", "güncelleme", e.getMessage());
        }
    }

    private void showSuccessMessage(String message) throws WeatherException {
        try {
            if (errorLabel == null) {
                throw new UIOperationException("Success label", "güncelleme", "Null referans");
            }

            errorLabel.setText("✅ " + message);
            errorLabel.setTextFill(Color.web("#4CAF50"));
            errorLabel.setVisible(true);

        } catch (Exception e) {
            throw new UIOperationException("Success label", "güncelleme", e.getMessage());
        }
    }

    private void startErrorClearTimer() {
        try {
            new Thread(() -> {
                try {
                    Thread.sleep(5000);
                    javafx.application.Platform.runLater(() -> {
                        try {
                            if (errorLabel != null) {
                                errorLabel.setVisible(false);
                            }
                        } catch (Exception e) {
                            System.err.println("Error label temizlenemedi: " + e.getMessage());
                        }
                    });
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        } catch (Exception e) {
            System.err.println("Error timer başlatılamadı: " + e.getMessage());
        }
    }

    public int getFailedAttemptCount(String username) {
        try {
            Integer attempts = failedAttempts.get(username);
            return attempts != null ? attempts : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean isUserLocked(String username) {
        try {
            return isUserTimeLocked(username);
        } catch (Exception e) {
            return false;
        }
    }

    public void clearUserLock(String username) {
        try {
            failedAttempts.remove(username);
            lockTimes.remove(username);
        } catch (Exception e) {
            System.err.println("Kullanıcı kilidi kaldırılamadı: " + e.getMessage());
        }
    }

    public long getRemainingLockTime(String username) {
        try {
            LocalDateTime lockTime = lockTimes.get(username);
            if (lockTime == null) {
                return 0;
            }

            long secondsPassed = ChronoUnit.SECONDS.between(lockTime, LocalDateTime.now());
            long remaining = LOCK_DURATION_SECONDS - secondsPassed;
            return Math.max(0, remaining);

        } catch (Exception e) {
            return 0;
        }
    }

    public static void addUser(User user) throws WeatherException {
        try {
            if (user == null) {
                throw new DataProcessingException("Kullanıcı", "ekleme", "Null kullanıcı");
            }

            if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
                throw new InvalidCityNameException("Geçersiz kullanıcı adı");
            }

            for (User existingUser : users) {
                if (existingUser != null && existingUser.getUsername().equals(user.getUsername())) {
                    throw new DataProcessingException("Kullanıcı", "ekleme", "Kullanıcı zaten mevcut");
                }
            }

            users.add(user);

        } catch (Exception e) {
            throw new DataProcessingException("Kullanıcı", "ekleme", e.getMessage());
        }
    }

    public static boolean removeUser(String username) throws WeatherException {
        try {
            if (username == null || username.trim().isEmpty()) {
                throw new InvalidCityNameException("Geçersiz kullanıcı adı");
            }

            for (User user : users) {
                if (user != null && user.getUsername().equals(username)) {
                    users.remove(user);
                    return true;
                }
            }

            return false;

        } catch (Exception e) {
            throw new DataProcessingException("Kullanıcı", "silme", e.getMessage());
        }
    }
}