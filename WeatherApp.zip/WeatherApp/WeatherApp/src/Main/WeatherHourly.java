package Main;

public class WeatherHourly {
    private String hour;
    private double temp;
    private String description;
    private String icon;

    public WeatherHourly(String hour, double temp, String description, String icon) {
        this.hour = hour;
        this.temp = temp;
        this.description = description;
        this.icon = icon;
    }

    public String getHour() {
        return hour;
    }

    public double getTemperature() {
        return temp;
    }

    public String getDescription() {
        return description;
    }

    public String getIcon() {
        return icon;
    }

    @Override
    public String toString() {
        String emoji = WeatherIcons.iconFor(description , icon);
        return hour + ": " + description + " " + emoji + ", " + temp + "°C";
    }
}
