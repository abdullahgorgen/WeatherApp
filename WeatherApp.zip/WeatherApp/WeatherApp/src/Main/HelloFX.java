package Main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HelloFX extends Application {
    private static Stage mainStage;
    private static User currentUser;

    @Override
    public void start(Stage primaryStage) throws Exception {
        mainStage = primaryStage;
        mainStage.setResizable(true);
        mainStage.setMinWidth(400);
        mainStage.setMinHeight(300);
        showLoginScreen();
    }
ss
    public static void showLoginScreen() throws Exception {
        Parent root = FXMLLoader.load(HelloFX.class.getResource("/Main/Login.fxml"));
        mainStage.setScene(new Scene(root, 650, 500));
        mainStage.setTitle("🌤 Hava Durumu - Giriş");
        mainStage.centerOnScreen();
        mainStage.show();
    }

    public static void showMainScreen() throws Exception {
        Parent root = FXMLLoader.load(HelloFX.class.getResource("/Main/main.fxml"));
        mainStage.setScene(new Scene(root, 1200, 750));
        mainStage.setTitle("🌤 Hava Durumu Uygulaması");
        mainStage.centerOnScreen();
        mainStage.show();
    }

    public static void showRegisterScreen() throws Exception {
        Parent root = FXMLLoader.load(HelloFX.class.getResource("/Main/Register.fxml"));
        mainStage.setScene(new Scene(root, 800, 700));
        mainStage.setTitle("📝 Kayıt Ol - Hava Durumu");
        mainStage.centerOnScreen();
        mainStage.show();
    }

    public static void showGraphVisualization(String city) throws Exception {
        FXMLLoader loader = new FXMLLoader(HelloFX.class.getResource("/Main/GraphVisualization.fxml"));
        Parent root = loader.load();

        GraphVisualizationController controller = loader.getController();
        controller.setCity(city);

        mainStage.setScene(new Scene(root, 1200, 800));
        mainStage.setTitle("🌐 " + city + " - Graph Ağ Haritası");
        mainStage.centerOnScreen();
        mainStage.show();
    }

    public static void showWeeklyWeather(String city) throws Exception {
        FXMLLoader loader = new FXMLLoader(HelloFX.class.getResource("/Main/WeeklyWeather.fxml"));
        Parent root = loader.load();

        WeeklyWeatherController controller = loader.getController();
        controller.setCity(city);

        mainStage.setScene(new Scene(root, 600, 500));
        mainStage.setTitle("📅 " + city + " - Haftalık Hava Durumu");
        mainStage.centerOnScreen();
        mainStage.show();
    }

    public static Stage getMainStage() {
        return mainStage;
    }

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void main(String[] args) {
        launch(args);
    }
}