package Main;

public class WeatherIcons {

    public static String iconFor(String desc, String iconCode) {
        if (desc == null) desc = "";
        if (iconCode == null) iconCode = "";

        desc = desc.toLowerCase();

        if (desc.contains("güneş") || desc.contains("açık") || desc.contains("berrak") ||
                iconCode.startsWith("01")) {
            return "/icons/sun.png";
        }

        if (desc.contains("parçalı") || desc.contains("az bulut") ||
                iconCode.startsWith("02")) {
            return "/icons/partlycloud.png";
        }

        if (desc.contains("bulut") || desc.contains("kapalı") ||
                iconCode.startsWith("03") || iconCode.startsWith("04")) {
            return "/icons/clouds.png";
        }

        if (desc.contains("yağmur") || desc.contains("sağanak") || desc.contains("çisenti") ||
                iconCode.startsWith("09") || iconCode.startsWith("10")) {
            return "/icons/rain.png";
        }

        if (desc.contains("fırtına") || desc.contains("gökgürültü") || desc.contains("şimşek") ||
                iconCode.startsWith("11")) {
            return "/icons/rain.png";
        }

        if (desc.contains("kar") || desc.contains("dolu") ||
                iconCode.startsWith("13")) {
            return "/icons/snow.png";
        }

        if (desc.contains("sis") || desc.contains("pus") || desc.contains("duman") ||
                desc.contains("toz") || iconCode.startsWith("50")) {
            return "/icons/fog.png";
        }

        if (desc.contains("rüzgar") || desc.contains("esinti")) {
            return "/icons/wind.png";
        }


        // Sıcaklık bazlı durumlar
        if (desc.contains("sıcak") || desc.contains("kavurucu")) {
            return "/icons/sun.png";
        }

        if (desc.contains("soğuk") || desc.contains("dondurucu")) {
            return "/icons/snow.png";
        }


        return "/icons/clouds.png";
    }

    public static String iconFor(String desc) {
        return iconFor(desc, "");
    }

    public static boolean isNightIcon(String iconCode) {
        return iconCode != null && iconCode.endsWith("n");
    }

    public static String getWeatherCategory(String desc, String iconCode) {
        desc = desc != null ? desc.toLowerCase() : "";
        iconCode = iconCode != null ? iconCode : "";

        if (desc.contains("güneş") || iconCode.startsWith("01")) return "sun";
        if (desc.contains("yağmur") || iconCode.startsWith("09") || iconCode.startsWith("10")) return "rain";
        if (desc.contains("kar") || iconCode.startsWith("13")) return "snow";
        if (desc.contains("fırtına") || iconCode.startsWith("11")) return "rain";
        if (desc.contains("bulut") || iconCode.startsWith("02") || iconCode.startsWith("03") || iconCode.startsWith("04")) return "clouds";
        if (desc.contains("sis") || iconCode.startsWith("50")) return "fog";

        return "unknown";
    }
}