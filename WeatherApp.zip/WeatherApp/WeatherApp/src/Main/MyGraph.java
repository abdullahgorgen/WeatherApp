package Main;

import java.util.*;

public class MyGraph<T> {
    private MyLinkedList<VertexEntry<T>> adjacencyList;

    public MyGraph() {
        this.adjacencyList = new MyLinkedList<>();
    }

    private static class VertexEntry<T> {
        T vertex;
        MyLinkedList<Edge<T>> edges;

        VertexEntry(T vertex) {
            this.vertex = vertex;
            this.edges = new MyLinkedList<>();
        }
    }

    public static class Edge<T> {
        private T destination;
        private double weight;
        private String label;

        public Edge(T destination, double weight, String label) {
            this.destination = destination;
            this.weight = weight;
            this.label = label;
        }

        public T getDestination() { return destination; }
        public double getWeight() { return weight; }
        public String getLabel() { return label; }

        @Override
        public String toString() {
            return String.format("-> %s (%s)", destination, label);
        }
    }

    private VertexEntry<T> findVertex(T vertex) {
        for (VertexEntry<T> entry : adjacencyList) {
            if (entry.vertex.equals(vertex)) {
                return entry;
            }
        }
        return null;
    }

    private VertexEntry<T> getOrCreateVertex(T vertex) {
        VertexEntry<T> entry = findVertex(vertex);
        if (entry == null) {
            entry = new VertexEntry<>(vertex);
            adjacencyList.add(entry);
        }
        return entry;
    }

    public void addVertex(T vertex) {
        if (findVertex(vertex) == null) {
            adjacencyList.add(new VertexEntry<>(vertex));
        }
    }

    public void addDirectedEdge(T source, T destination, double weight, String label) {
        VertexEntry<T> sourceEntry = getOrCreateVertex(source);
        getOrCreateVertex(destination);
        sourceEntry.edges.add(new Edge<>(destination, weight, label));
    }

    public void addUndirectedEdge(T source, T destination, double weight, String label) {
        addDirectedEdge(source, destination, weight, label);
        addDirectedEdge(destination, source, weight, label);
    }

    public MyLinkedList<Edge<T>> getNeighbors(T vertex) {
        VertexEntry<T> entry = findVertex(vertex);
        return entry != null ? entry.edges : new MyLinkedList<>();
    }

    public List<Edge<T>> getNeighborsAsList(T vertex) {
        MyLinkedList<Edge<T>> neighbors = getNeighbors(vertex);
        return neighbors.toList();
    }

    public Set<T> getAllVertices() {
        Set<T> vertices = new HashSet<>();
        for (VertexEntry<T> entry : adjacencyList) {
            vertices.add(entry.vertex);
        }
        return vertices;
    }

    public MyLinkedList<T> getAllVerticesAsList() {
        MyLinkedList<T> vertices = new MyLinkedList<>();
        for (VertexEntry<T> entry : adjacencyList) {
            vertices.add(entry.vertex);
        }
        return vertices;
    }

    public List<T> breadthFirstSearch(T startVertex) {
        MyLinkedList<T> result = new MyLinkedList<>();
        MyLinkedList<T> visited = new MyLinkedList<>();
        MyQueue<T> queue = new MyQueue<>();

        queue.enqueue(startVertex);
        visited.add(startVertex);

        while (!queue.isEmpty()) {
            T current = queue.dequeue();
            result.add(current);

            MyLinkedList<Edge<T>> neighbors = getNeighbors(current);
            for (Edge<T> edge : neighbors) {
                T neighbor = edge.getDestination();
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.enqueue(neighbor);
                }
            }
        }

        return result.toList();
    }

    public List<T> depthFirstSearch(T startVertex) {
        MyLinkedList<T> result = new MyLinkedList<>();
        MyLinkedList<T> visited = new MyLinkedList<>();
        MyStack<T> stack = new MyStack<>();

        stack.push(startVertex);

        while (!stack.isEmpty()) {
            T current = stack.pop();

            if (!visited.contains(current)) {
                visited.add(current);
                result.add(current);

                MyLinkedList<Edge<T>> neighbors = getNeighbors(current);
                for (int i = neighbors.size() - 1; i >= 0; i--) {
                    T neighbor = neighbors.get(i).getDestination();
                    if (!visited.contains(neighbor)) {
                        stack.push(neighbor);
                    }
                }
            }
        }

        return result.toList();
    }

    public Map<T, Double> dijkstra(T startVertex) {
        Map<T, Double> distances = new HashMap<>();
        MyLinkedList<T> unvisited = new MyLinkedList<>();
        MyLinkedList<T> visited = new MyLinkedList<>();

        for (VertexEntry<T> entry : adjacencyList) {
            T vertex = entry.vertex;
            distances.put(vertex, vertex.equals(startVertex) ? 0.0 : Double.MAX_VALUE);
            unvisited.add(vertex);
        }

        while (!unvisited.isEmpty()) {
            T current = null;
            double minDistance = Double.MAX_VALUE;

            for (T vertex : unvisited) {
                double dist = distances.get(vertex);
                if (dist < minDistance) {
                    minDistance = dist;
                    current = vertex;
                }
            }

            if (current == null || minDistance == Double.MAX_VALUE) break;

            unvisited.remove(current);
            visited.add(current);

            MyLinkedList<Edge<T>> neighbors = getNeighbors(current);
            for (Edge<T> edge : neighbors) {
                T neighbor = edge.getDestination();
                if (!visited.contains(neighbor)) {
                    double newDistance = distances.get(current) + edge.getWeight();
                    if (newDistance < distances.get(neighbor)) {
                        distances.put(neighbor, newDistance);
                    }
                }
            }
        }

        return distances;
    }

    public MyLinkedList<Edge<T>> primMST() {
        MyLinkedList<Edge<T>> mst = new MyLinkedList<>();
        if (adjacencyList.isEmpty()) return mst;

        MyLinkedList<T> visited = new MyLinkedList<>();
        MyLinkedList<Edge<T>> edgeQueue = new MyLinkedList<>();

        T startVertex = adjacencyList.get(0).vertex;
        visited.add(startVertex);

        MyLinkedList<Edge<T>> startEdges = getNeighbors(startVertex);
        for (Edge<T> edge : startEdges) {
            edgeQueue.add(edge);
        }

        while (!edgeQueue.isEmpty() && visited.size() < adjacencyList.size()) {
            Edge<T> minEdge = null;
            int minIndex = -1;
            double minWeight = Double.MAX_VALUE;

            for (int i = 0; i < edgeQueue.size(); i++) {
                Edge<T> edge = edgeQueue.get(i);
                if (edge.getWeight() < minWeight && !visited.contains(edge.getDestination())) {
                    minWeight = edge.getWeight();
                    minEdge = edge;
                    minIndex = i;
                }
            }

            if (minEdge != null) {
                edgeQueue.remove(minIndex);
                T destination = minEdge.getDestination();

                if (!visited.contains(destination)) {
                    visited.add(destination);
                    mst.add(minEdge);

                    MyLinkedList<Edge<T>> newEdges = getNeighbors(destination);
                    for (Edge<T> edge : newEdges) {
                        if (!visited.contains(edge.getDestination())) {
                            edgeQueue.add(edge);
                        }
                    }
                }
            } else {
                break;
            }
        }

        return mst;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Graph:\n");
        for (VertexEntry<T> entry : adjacencyList) {
            sb.append(entry.vertex).append(" ");
            for (Edge<T> edge : entry.edges) {
                sb.append(edge).append(" ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public boolean hasCycle() {
        MyLinkedList<T> visited = new MyLinkedList<>();
        MyLinkedList<T> recursionStack = new MyLinkedList<>();

        for (VertexEntry<T> entry : adjacencyList) {
            T vertex = entry.vertex;
            if (!visited.contains(vertex)) {
                if (hasCycleHelper(vertex, visited, recursionStack)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean hasCycleHelper(T vertex, MyLinkedList<T> visited, MyLinkedList<T> recursionStack) {
        visited.add(vertex);
        recursionStack.add(vertex);

        MyLinkedList<Edge<T>> neighbors = getNeighbors(vertex);
        for (Edge<T> edge : neighbors) {
            T neighbor = edge.getDestination();

            if (!visited.contains(neighbor)) {
                if (hasCycleHelper(neighbor, visited, recursionStack)) {
                    return true;
                }
            } else if (recursionStack.contains(neighbor)) {
                return true;
            }
        }

        recursionStack.remove(vertex);
        return false;
    }

    public int size() {
        return adjacencyList.size();
    }

    public boolean isEmpty() {
        return adjacencyList.isEmpty();
    }
}