package Main;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class HourlyWeatherController {

    @FXML private Label cityLabel;
    @FXML private LineChart<String, Number> hourlyChart;

    private String city;
    private boolean isDataLoading = false;

    public void setCity(String city) {
        try {
            if (city == null || city.trim().isEmpty()) {
                throw new InvalidCityNameException("Boş şehir adı");
            }
            if (city.trim().length() < 2) {
                throw new InvalidCityNameException(city);
            }

            this.city = city;
            cityLabel.setText(city + " - Saatlik Hava Durumu");
            loadHourlyWeather();

        } catch (WeatherException e) {
            showErrorAlert("Şehir Hatası", e.getMessage());
            closeWindowSafely();
        }
    }

    private void loadHourlyWeather() {
        if (isDataLoading) {
            showErrorAlert("Uyarı", "Veri yükleme devam ediyor");
            return;
        }

        isDataLoading = true;

        new Thread(() -> {
            try {
                MyLinkedList<WeatherHourly> hours = fetchHourlyData();
                XYChart.Series<String, Number> tempSeries = createTemperatureSeries(hours);
                double[] tempRange = calculateTemperatureRange(hours);

                Platform.runLater(() -> {
                    try {
                        updateChart(tempSeries, tempRange[0], tempRange[1]);
                        isDataLoading = false;
                    } catch (WeatherException e) {
                        showErrorAlert("UI Hatası", e.getMessage());
                        isDataLoading = false;
                    }
                });

            } catch (WeatherException e) {
                Platform.runLater(() -> {
                    showErrorAlert("Veri Hatası", e.getMessage());
                    isDataLoading = false;
                });
            }
        }).start();
    }

    private MyLinkedList<WeatherHourly> fetchHourlyData() throws WeatherException {
        try {
            MyLinkedList<WeatherHourly> hours = WeatherService.fetchHourly(city);

            if (hours == null || hours.isEmpty()) {
                throw new WeatherDataNotFoundException(city);
            }

            return hours;
        } catch (Exception e) {
            throw new WeatherServiceException("saatlik veri alma", e.getMessage());
        }
    }

    private XYChart.Series<String, Number> createTemperatureSeries(MyLinkedList<WeatherHourly> hours)
            throws WeatherException {
        try {
            XYChart.Series<String, Number> tempSeries = new XYChart.Series<>();
            tempSeries.setName("🌡️ Sıcaklık");

            int validCount = 0;
            for (WeatherHourly wh : hours) {
                if (wh != null && wh.getHour() != null && !Double.isNaN(wh.getTemperature())) {
                    tempSeries.getData().add(new XYChart.Data<>(wh.getHour(), wh.getTemperature()));
                    validCount++;
                }
            }

            if (validCount == 0) {
                throw new DataProcessingException("Sıcaklık serisi", "oluşturma", "Geçerli veri bulunamadı");
            }

            return tempSeries;
        } catch (Exception e) {
            throw new DataProcessingException("Sıcaklık serisi", "oluşturma", e.getMessage());
        }
    }

    private double[] calculateTemperatureRange(MyLinkedList<WeatherHourly> hours) throws WeatherException {
        double minTemp = Double.MAX_VALUE;
        double maxTemp = Double.MIN_VALUE;
        boolean hasValidData = false;

        for (WeatherHourly wh : hours) {
            if (wh != null && !Double.isNaN(wh.getTemperature())) {
                double temp = wh.getTemperature();
                if (temp < minTemp) minTemp = temp;
                if (temp > maxTemp) maxTemp = temp;
                hasValidData = true;
            }
        }

        if (!hasValidData) {
            throw new DataProcessingException("Sıcaklık aralığı", "hesaplama", "Geçerli sıcaklık verisi bulunamadı");
        }

        return new double[]{minTemp, maxTemp};
    }

    private void updateChart(XYChart.Series<String, Number> tempSeries, double minTemp, double maxTemp)
            throws WeatherException {
        try {
            if (hourlyChart == null) {
                throw new UIOperationException("Chart", "güncelleme", "Chart referansı null");
            }

            hourlyChart.getData().clear();
            hourlyChart.getData().add(tempSeries);
            setupYAxis(minTemp, maxTemp);

            hourlyChart.setCreateSymbols(true);
            hourlyChart.setLegendVisible(true);
            hourlyChart.setTitle(city + " - Saatlik Sıcaklık Değişimi");

        } catch (Exception e) {
            throw new UIOperationException("Chart", "güncelleme", e.getMessage());
        }
    }

    private void setupYAxis(double minTemp, double maxTemp) throws WeatherException {
        try {
            if (!(hourlyChart.getYAxis() instanceof javafx.scene.chart.NumberAxis)) {
                throw new UIOperationException("Y ekseni", "setup", "NumberAxis tipinde değil");
            }

            javafx.scene.chart.NumberAxis yAxis = (javafx.scene.chart.NumberAxis) hourlyChart.getYAxis();
            double tempRange = maxTemp - minTemp;
            double margin = Math.max(tempRange * 0.2, 2.0);

            yAxis.setLowerBound(minTemp - margin);
            yAxis.setUpperBound(maxTemp + margin);
            yAxis.setAutoRanging(false);
            yAxis.setTickUnit(Math.max(tempRange / 4.0, 1.0));

            yAxis.setTickLabelFormatter(new javafx.util.StringConverter<Number>() {
                @Override
                public String toString(Number object) {
                    return object == null ? "0.0°C" : String.format("%.1f°C", object.doubleValue());
                }
                @Override
                public Number fromString(String string) {
                    try {
                        return Double.parseDouble(string.replace("°C", "").trim());
                    } catch (NumberFormatException e) {
                        return 0.0;
                    }
                }
            });

        } catch (Exception e) {
            throw new UIOperationException("Y ekseni", "ayarlama", e.getMessage());
        }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void closeWindowSafely() {
        try {
            Stage stage = (Stage) cityLabel.getScene().getWindow();
            if (stage != null) {
                stage.close();
            }
        } catch (Exception e) {
            System.err.println("Pencere kapatma hatası: " + e.getMessage());
        }
    }

    @FXML
    private void onBack() {
        if (isDataLoading) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Uyarı");
            alert.setContentText("Veri yükleme devam ediyor. Lütfen bekleyin...");
            alert.showAndWait();
            return;
        }
        closeWindowSafely();
    }

    public boolean isDataCurrentlyLoading() {
        return isDataLoading;
    }

    public String getCurrentCity() {
        return city;
    }
}