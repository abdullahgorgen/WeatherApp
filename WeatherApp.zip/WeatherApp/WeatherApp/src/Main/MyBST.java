package Main;

public class MyBST<K extends Comparable<K>, V> {
    private Node<K, V> root;
    private int size;

    private static class Node<K, V> {
        K key;
        V value;
        Node<K, V> left;
        Node<K, V> right;

        Node(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }

    public MyBST() {
        root = null;
        size = 0;
    }

    public void put(K key, V value) {
        root = putRec(root, key, value);
    }

    private Node<K, V> putRec(Node<K, V> node, K key, V value) {
        if (node == null) {
            size++;
            return new Node<>(key, value);
        }

        int cmp = key.compareTo(node.key);
        if (cmp < 0) {
            node.left = putRec(node.left, key, value);
        } else if (cmp > 0) {
            node.right = putRec(node.right, key, value);
        } else {
            node.value = value;
        }

        return node;
    }

    public boolean putIfAbsent(K key, V value) {
        if (containsKey(key)) {
            return false;
        }
        put(key, value);
        return true;
    }

    public boolean addLocationIfNotExists(K key, V value) {
        return putIfAbsent(key, value);
    }

    public V get(K key) {
        return getRec(root, key);
    }

    private V getRec(Node<K, V> node, K key) {
        if (node == null) return null;

        int cmp = key.compareTo(node.key);
        if (cmp == 0) return node.value;
        else if (cmp < 0) return getRec(node.left, key);
        else return getRec(node.right, key);
    }

    public boolean containsKey(K key) {
        return get(key) != null;
    }

    public boolean putIfChanged(K key, V value) {
        V currentValue = get(key);
        if (currentValue != null && currentValue.equals(value)) {
            return false;
        }
        put(key, value);
        return true;
    }

    public boolean remove(K key) {
        int oldSize = size;
        root = removeRec(root, key);
        return size < oldSize;
    }

    private Node<K, V> removeRec(Node<K, V> node, K key) {
        if (node == null) return null;

        int cmp = key.compareTo(node.key);
        if (cmp < 0) {
            node.left = removeRec(node.left, key);
        } else if (cmp > 0) {
            node.right = removeRec(node.right, key);
        } else {
            size--;

            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            Node<K, V> successor = findMin(node.right);
            node.key = successor.key;
            node.value = successor.value;
            node.right = removeRec(node.right, successor.key);
            size++;
        }
        return node;
    }

    private Node<K, V> findMin(Node<K, V> node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }

    public MyLinkedList<K> keys() {
        MyLinkedList<K> result = new MyLinkedList<>();
        keysInOrder(root, result);
        return result;
    }

    private void keysInOrder(Node<K, V> node, MyLinkedList<K> result) {
        if (node != null) {
            keysInOrder(node.left, result);
            result.add(node.key);
            keysInOrder(node.right, result);
        }
    }

    public MyLinkedList<V> values() {
        MyLinkedList<V> result = new MyLinkedList<>();
        valuesInOrder(root, result);
        return result;
    }

    private void valuesInOrder(Node<K, V> node, MyLinkedList<V> result) {
        if (node != null) {
            valuesInOrder(node.left, result);
            result.add(node.value);
            valuesInOrder(node.right, result);
        }
    }

    public static class Entry<K, V> {
        private K key;
        private V value;

        public Entry(K key, V value) {
            this.key = key;
            this.value = value;
        }

        public K getKey() { return key; }
        public V getValue() { return value; }
    }

    public MyLinkedList<Entry<K, V>> entrySet() {
        MyLinkedList<Entry<K, V>> result = new MyLinkedList<>();
        entriesInOrder(root, result);
        return result;
    }

    private void entriesInOrder(Node<K, V> node, MyLinkedList<Entry<K, V>> result) {
        if (node != null) {
            entriesInOrder(node.left, result);
            result.add(new Entry<>(node.key, node.value));
            entriesInOrder(node.right, result);
        }
    }

    public K findMinKey() {
        if (root == null) return null;
        return findMin(root).key;
    }

    public K findMaxKey() {
        if (root == null) return null;
        Node<K, V> node = root;
        while (node.right != null) {
            node = node.right;
        }
        return node.key;
    }

    public V findMinValue() {
        if (root == null) return null;
        return findMin(root).value;
    }

    public V findMaxValue() {
        if (root == null) return null;
        Node<K, V> node = root;
        while (node.right != null) {
            node = node.right;
        }
        return node.value;
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return root == null;
    }

    public void clear() {
        root = null;
        size = 0;
    }

    @Deprecated
    public void insert(K key) {
        put(key, null);
    }

    @Deprecated
    public boolean contains(K key) {
        return containsKey(key);
    }
}