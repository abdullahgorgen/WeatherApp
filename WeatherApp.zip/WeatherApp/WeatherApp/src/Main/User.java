package Main;

import java.time.LocalDateTime;

public class User {
    private String username;
    private String password;
    private boolean isAdmin;
    private MyLinkedList<String> favoriteCities;
    private LocalDateTime lastLogin;
    private LocalDateTime registrationDate;
    private boolean isActive;

    public User(String username, String password, boolean isAdmin, MyLinkedList<String> favoriteCities) {
        this.username = username;
        this.password = password;
        this.isAdmin = isAdmin;
        this.favoriteCities = favoriteCities != null ? favoriteCities : new MyLinkedList<>();
        this.registrationDate = LocalDateTime.now();
        this.lastLogin = null;
        this.isActive = true;
    }

    public User(String username, String password, boolean isAdmin) {
        this(username, password, isAdmin, new MyLinkedList<>());
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public boolean isAdmin() { return isAdmin; }
    public MyLinkedList<String> getFavoriteCities() { return favoriteCities; }
    public void setFavoriteCities(MyLinkedList<String> favoriteCities) {
        this.favoriteCities = favoriteCities;
    }

    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }

    public LocalDateTime getRegistrationDate() { return registrationDate; }
    public void setRegistrationDate(LocalDateTime registrationDate) {
        this.registrationDate = registrationDate;
    }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { this.isActive = active; }

    public void setAdmin(boolean admin) { this.isAdmin = admin; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }

    public String getDisplayInfo() {
        String role = isAdmin ? "👑 Admin" : "👤 Kullanıcı";
        String favoriteCitiesInfo = getFavoriteCitiesAsString();

        return String.format("%s [%s] - %s",
                username, role, favoriteCitiesInfo);
    }

    public int getFavoriteCitiesCount() {
        return favoriteCities.size();
    }

    public String getFavoriteCitiesAsString() {
        if (favoriteCities.isEmpty()) {
            return "Favori şehir yok";
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < favoriteCities.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(favoriteCities.get(i));
            if (i >= 2) { // İlk 3 şehri göster
                if (favoriteCities.size() > 3) {
                    sb.append(" (+").append(favoriteCities.size() - 3).append(" daha)");
                }
                break;
            }
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return getDisplayInfo();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        User user = (User) obj;
        return username.equals(user.username);
    }

    @Override
    public int hashCode() {
        return username.hashCode();
    }
}