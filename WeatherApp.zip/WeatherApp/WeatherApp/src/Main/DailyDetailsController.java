package Main;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class DailyDetailsController {

    @FXML private Label dateLabel;
    @FXML private LineChart<String, Number> dailyChart;

    private String city;
    private String selectedDate;
    private boolean isLoading = false;

    public void setCityAndDate(String city, String selectedDate) {
        try {
            if (city == null || city.trim().isEmpty()) {
                throw new InvalidCityNameException("Boş şehir adı");
            }
            if (selectedDate == null || selectedDate.trim().isEmpty()) {
                throw new DataProcessingException("Tarih", "doğrulama", "Boş tarih");
            }
            if (!selectedDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
                throw new DataProcessingException("Tarih", "format kontrolü", "Geçersiz tarih formatı: " + selectedDate);
            }

            this.city = city;
            this.selectedDate = selectedDate;
            dateLabel.setText(city + " - " + selectedDate + " Saatlik Hava Durumu");
            loadDailyDetails();

        } catch (WeatherException e) {
            showErrorAlert("Giriş Hatası", e.getMessage());
            closeWindowSafely();
        }
    }

    private void loadDailyDetails() {
        if (isLoading) {
            showErrorAlert("Uyarı", "Veri yükleme devam ediyor");
            return;
        }

        isLoading = true;

        new Thread(() -> {
            try {
                MyLinkedList<WeatherHourly> allHours = fetchHourlyData();
                MyLinkedList<WeatherHourly> dayHours = filterDataForSelectedDate(allHours);
                XYChart.Series<String, Number> tempSeries = createTemperatureSeries(dayHours);

                Platform.runLater(() -> {
                    try {
                        updateChart(tempSeries);
                        isLoading = false;
                    } catch (WeatherException e) {
                        showErrorAlert("UI Hatası", e.getMessage());
                        isLoading = false;
                    }
                });

            } catch (WeatherException e) {
                Platform.runLater(() -> {
                    showErrorAlert("Veri Hatası", e.getMessage());
                    isLoading = false;
                });
            }
        }).start();
    }

    private MyLinkedList<WeatherHourly> fetchHourlyData() throws WeatherException {
        try {
            MyLinkedList<WeatherHourly> allHours = WeatherService.fetchHourly(city);

            if (allHours == null || allHours.isEmpty()) {
                throw new WeatherDataNotFoundException(city, "Saatlik veri bulunamadı");
            }

            return allHours;
        } catch (Exception e) {
            throw new WeatherServiceException("saatlik veri alma", e.getMessage());
        }
    }

    private MyLinkedList<WeatherHourly> filterDataForSelectedDate(MyLinkedList<WeatherHourly> allHours)
            throws WeatherException {
        try {
            MyLinkedList<WeatherHourly> dayHours = new MyLinkedList<>();
            String targetDay = selectedDate.substring(8, 10);

            for (WeatherHourly wh : allHours) {
                if (wh != null && wh.getHour() != null && wh.getHour().startsWith(targetDay)) {
                    dayHours.add(wh);
                }
            }

            if (dayHours.isEmpty()) {
                if (allHours.isEmpty()) {
                    throw new WeatherDataNotFoundException(city, "Seçilen tarih için veri bulunamadı");
                }
                return allHours;
            }

            return dayHours;

        } catch (Exception e) {
            throw new DataProcessingException("Saatlik veri", "filtreleme", "Tarih filtreleme başarısız: " + selectedDate);
        }
    }

    private XYChart.Series<String, Number> createTemperatureSeries(MyLinkedList<WeatherHourly> dayHours)
            throws WeatherException {
        try {
            XYChart.Series<String, Number> tempSeries = new XYChart.Series<>();
            tempSeries.setName("🌡️ Sıcaklık");

            int validCount = 0;
            for (WeatherHourly wh : dayHours) {
                if (wh != null && wh.getHour() != null && !Double.isNaN(wh.getTemperature())) {
                    tempSeries.getData().add(new XYChart.Data<>(wh.getHour(), wh.getTemperature()));
                    validCount++;
                }
            }

            if (validCount == 0) {
                throw new DataProcessingException("Sıcaklık serisi", "oluşturma", "Geçerli veri bulunamadı");
            }

            return tempSeries;

        } catch (Exception e) {
            throw new DataProcessingException("Sıcaklık serisi", "oluşturma", e.getMessage());
        }
    }

    private void updateChart(XYChart.Series<String, Number> tempSeries) throws WeatherException {
        try {
            if (dailyChart == null) {
                throw new UIOperationException("Chart", "güncelleme", "Chart referansı null");
            }

            dailyChart.getData().clear();
            dailyChart.getData().add(tempSeries);

            dailyChart.setCreateSymbols(true);
            dailyChart.setLegendVisible(true);
            dailyChart.setTitle(city + " - " + selectedDate + " Sıcaklık Değişimi");

            setupYAxisIfNeeded();

        } catch (Exception e) {
            throw new UIOperationException("Chart", "güncelleme", e.getMessage());
        }
    }

    private void setupYAxisIfNeeded() throws WeatherException {
        try {
            if (dailyChart.getYAxis() instanceof javafx.scene.chart.NumberAxis) {
                javafx.scene.chart.NumberAxis yAxis = (javafx.scene.chart.NumberAxis) dailyChart.getYAxis();

                yAxis.setTickLabelFormatter(new javafx.util.StringConverter<Number>() {
                    @Override
                    public String toString(Number object) {
                        return object == null ? "0°C" : String.format("%.1f°C", object.doubleValue());
                    }
                    @Override
                    public Number fromString(String string) {
                        try {
                            return Double.parseDouble(string.replace("°C", "").trim());
                        } catch (NumberFormatException e) {
                            return 0.0;
                        }
                    }
                });
            }
        } catch (Exception e) {
            throw new UIOperationException("Y ekseni", "ayarlama", e.getMessage());
        }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void closeWindowSafely() {
        try {
            Stage stage = (Stage) dateLabel.getScene().getWindow();
            if (stage != null) {
                stage.close();
            }
        } catch (Exception e) {
            System.err.println("Pencere kapatma hatası: " + e.getMessage());
        }
    }

    @FXML
    private void onBack() {
        if (isLoading) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Uyarı");
            alert.setContentText("Veri yükleme devam ediyor. Lütfen bekleyin...");
            alert.showAndWait();
            return;
        }
        closeWindowSafely();
    }

    public boolean isCurrentlyLoading() {
        return isLoading;
    }

    public String getCurrentCity() {
        return city;
    }

    public String getSelectedDate() {
        return selectedDate;
    }
}