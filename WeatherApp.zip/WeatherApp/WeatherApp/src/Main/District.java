package Main;

public class District {
    private String name;
    private String cityName;
    private double temperature;
    private String description;
    private String icon;

    public District(String name, String cityName, double temperature, String description, String icon) {
        this.name = name;
        this.cityName = cityName;
        this.temperature = temperature;
        this.description = description;
        this.icon = icon;
    }

    public String getName() { return name; }
    public String getCityName() { return cityName; }
    public double getTemperature() { return temperature; }
    public String getDescription() { return description; }
    public String getIcon() { return icon; }

    @Override
    public String toString() {
        return String.format("%s: %.1f°C - %s", name, temperature, description);
    }
}