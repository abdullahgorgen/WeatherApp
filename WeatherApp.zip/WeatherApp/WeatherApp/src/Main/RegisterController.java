package Main;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.geometry.Pos;
import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

public class RegisterController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField cityInputField;
    @FXML private ScrollPane citiesScrollPane;
    @FXML private VBox citiesContainer;
    @FXML private Label errorLabel;

    private static final MyLinkedList<User> users = LoginController.getUsersList();
    private final MyLinkedList<String> favoriteCities = new MyLinkedList<>();
    private final MyBST<String, Boolean> validCityCache = new MyBST<>();

    private static final int MAX_FAVORITE_CITIES = 10;
    private static final int MIN_USERNAME_LENGTH = 3;
    private static final int MAX_USERNAME_LENGTH = 20;
    private static final int MIN_PASSWORD_LENGTH = 4;

    @FXML
    public void initialize() {
        try {
            setupUI();
            setupEventHandlers();
        } catch (Exception e) {
            showError("Uygulama başlatılamadı: " + e.getMessage());
        }
    }

    private void setupUI() {
        try {
            if (citiesScrollPane != null) {
                citiesScrollPane.setFitToWidth(true);
                citiesScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
                citiesScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
                citiesScrollPane.setStyle(citiesScrollPane.getStyle() +
                        "-fx-background: transparent; " +
                        "-fx-background-color: rgba(255, 255, 255, 0.1); " +
                        "-fx-background-radius: 15; " +
                        "-fx-border-radius: 15;");
            }

            if (errorLabel != null) {
                errorLabel.setVisible(false);
            }
        } catch (Exception e) {
            System.err.println("UI kurulum hatası: " + e.getMessage());
        }
    }

    private void setupEventHandlers() {
        try {
            if (cityInputField != null) {
                cityInputField.setOnAction(e -> onAddCity());
            }
        } catch (Exception e) {
            System.err.println("Event handler kurulum hatası: " + e.getMessage());
        }
    }

    @FXML
    private void onAddCity() {
        try {
            String cityName = getCityInput();
            validateCityAddition(cityName);

            String normalizedCityName = capitalizeCity(cityName);
            validateCityUniqueness(normalizedCityName);

            validateCityAsync(normalizedCityName)
                    .thenAccept(isValid -> {
                        Platform.runLater(() -> {
                            try {
                                if (isValid) {
                                    completeCityAddition(normalizedCityName);
                                } else {
                                    throw new WeatherDataNotFoundException(normalizedCityName, "Hava durumu servisi doğrulamadı");
                                }
                            } catch (WeatherException e) {
                                handleCityError(e.getMessage());
                            }
                        });
                    })
                    .exceptionally(throwable -> {
                        Platform.runLater(() -> handleCityError("Konum doğrulama hatası: " + throwable.getMessage()));
                        return null;
                    });

        } catch (WeatherException e) {
            handleCityError(e.getMessage());
        } catch (Exception e) {
            handleCityError("Beklenmeyen konum ekleme hatası: " + e.getMessage());
        }
    }

    private String getCityInput() throws WeatherException {
        try {
            if (cityInputField == null) {
                throw new UIOperationException("CityInputField", "erişim", "Null referans");
            }

            String cityName = cityInputField.getText();
            if (cityName == null) cityName = "";
            cityName = cityName.trim();

            if (cityName.isEmpty()) {
                throw new DataProcessingException("Konum adı", "doğrulama", "Boş olamaz");
            }
            if (cityName.length() < 2) {
                throw new DataProcessingException("Konum adı", "doğrulama", "En az 2 karakter olmalı");
            }
            if (cityName.length() > 50) {
                throw new DataProcessingException("Konum adı", "doğrulama", "En fazla 50 karakter olabilir");
            }
            if (!cityName.matches("^[a-zA-ZÇçĞğıİÖöŞşÜü\\s-]+$")) {
                throw new DataProcessingException("Konum adı", "doğrulama", "Sadece harf, boşluk ve tire içerebilir");
            }

            return cityName;

        } catch (Exception e) {
            throw new DataProcessingException("Konum adı", "doğrulama", e.getMessage());
        }
    }

    private void validateCityAddition(String cityName) throws WeatherException {
        if (favoriteCities.size() >= MAX_FAVORITE_CITIES) {
            throw new DataProcessingException("Favori konum", "ekleme",
                    "Maksimum " + MAX_FAVORITE_CITIES + " konum eklenebilir");
        }
    }

    private void validateCityUniqueness(String cityName) throws WeatherException {
        if (favoriteCities.contains(cityName)) {
            throw new DataProcessingException("Favori konum", "ekleme", "Bu konum zaten eklenmiş");
        }
    }

    private CompletableFuture<Boolean> validateCityAsync(String cityName) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return isValidCity(cityName);
            } catch (Exception e) {
                throw new RuntimeException("Async konum doğrulama hatası: " + e.getMessage(), e);
            }
        });
    }

    private boolean isValidCity(String cityName) {
        try {
            Boolean cachedResult = validCityCache.get(cityName);
            if (cachedResult != null) {
                return cachedResult;
            }

            Weather weather = WeatherService.fetchWeather(cityName);
            boolean isValid = weather != null &&
                    weather.getTemperature() != 0.0 &&
                    !Double.isNaN(weather.getTemperature()) &&
                    !weather.getDescription().toLowerCase().contains("not found");

            validCityCache.put(cityName, isValid);
            return isValid;

        } catch (Exception e) {
            try {
                validCityCache.put(cityName, false);
            } catch (Exception ignored) {}
            return false;
        }
    }

    private void completeCityAddition(String cityName) throws WeatherException {
        try {
            favoriteCities.add(cityName);
            addCityToUI(cityName);

            if (cityInputField != null) {
                cityInputField.clear();
            }

            showSuccess(cityName + " eklendi!");

        } catch (Exception e) {
            throw new DataProcessingException("Konum", "ekleme", e.getMessage());
        }
    }

    private void addCityToUI(String cityName) throws WeatherException {
        try {
            HBox cityBox = createCityBox();
            Label cityLabel = createCityLabel(cityName);
            Button removeButton = createRemoveButton(cityName, cityBox);

            cityBox.getChildren().addAll(cityLabel, removeButton);
            citiesContainer.getChildren().add(cityBox);

        } catch (Exception e) {
            throw new UIOperationException("CityBox", "oluşturma", e.getMessage());
        }
    }

    private HBox createCityBox() {
        HBox cityBox = new HBox(12);
        cityBox.setAlignment(Pos.CENTER);
        cityBox.setStyle("-fx-background-color: rgba(255, 255, 255, 0.25); " +
                "-fx-background-radius: 20; " +
                "-fx-padding: 12 16; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 4, 0, 0, 2);");
        return cityBox;
    }

    private Label createCityLabel(String cityName) {
        Label cityLabel = new Label("📍 " + cityName);
        cityLabel.setStyle("-fx-text-fill: white; " +
                "-fx-font-size: 15px; " +
                "-fx-font-weight: bold;");
        return cityLabel;
    }

    private Button createRemoveButton(String cityName, HBox cityBox) {
        Button removeButton = new Button("❌");
        removeButton.setStyle("-fx-background-color: #F44336; " +
                "-fx-text-fill: white; " +
                "-fx-background-radius: 15; " +
                "-fx-padding: 6 10; " +
                "-fx-font-size: 14px; " +
                "-fx-cursor: hand; " +
                "-fx-min-width: 35; " +
                "-fx-min-height: 35;");

        // Event handlers
        removeButton.setOnAction(e -> {
            try {
                removeCityFromFavorites(cityName, cityBox);
            } catch (Exception ex) {
                showError("Konum silinemedi: " + ex.getMessage());
            }
        });

        removeButton.setOnMouseEntered(e ->
                removeButton.setStyle(removeButton.getStyle() + "-fx-scale-x: 1.15; -fx-scale-y: 1.15;"));
        removeButton.setOnMouseExited(e ->
                removeButton.setStyle(removeButton.getStyle().replace("-fx-scale-x: 1.15; -fx-scale-y: 1.15;", "")));

        return removeButton;
    }

    private void removeCityFromFavorites(String cityName, HBox cityBox) throws WeatherException {
        try {
            favoriteCities.remove(cityName);
            citiesContainer.getChildren().remove(cityBox);
            showSuccess(cityName + " silindi!");
        } catch (Exception e) {
            throw new DataProcessingException("Konum", "silme", e.getMessage());
        }
    }

    private String capitalizeCity(String city) throws WeatherException {
        try {
            if (city == null || city.isEmpty()) {
                throw new DataProcessingException("Konum adı", "format", "Boş konum adı");
            }

            city = city.toLowerCase()
                    .replace("ı", "ı").replace("i", "i")
                    .replace("ğ", "ğ").replace("ü", "ü")
                    .replace("ş", "ş").replace("ö", "ö")
                    .replace("ç", "ç");

            return city.substring(0, 1).toUpperCase() + city.substring(1);

        } catch (Exception e) {
            throw new DataProcessingException("Konum adı", "format", e.getMessage());
        }
    }

    @FXML
    private void onRegister() {
        try {
            String username = getValidatedUsername();
            String password = getValidatedPassword();

            validateBusinessRules(username);

            User newUser = createNewUser(username, password);

            completeRegistration(newUser);

        } catch (WeatherException e) {
            handleRegistrationError(e.getMessage());
        } catch (Exception e) {
            handleRegistrationError("Beklenmeyen kayıt hatası: " + e.getMessage());
        }
    }

    private String getValidatedUsername() throws WeatherException {
        try {
            if (usernameField == null) {
                throw new UIOperationException("UsernameField", "erişim", "Null referans");
            }

            String username = usernameField.getText();
            if (username == null) username = "";
            username = username.trim();

            if (username.isEmpty()) {
                throw new DataProcessingException("Kullanıcı adı", "doğrulama", "Boş olamaz");
            }
            if (username.length() < MIN_USERNAME_LENGTH) {
                throw new DataProcessingException("Kullanıcı adı", "doğrulama",
                        "En az " + MIN_USERNAME_LENGTH + " karakter olmalı");
            }
            if (username.length() > MAX_USERNAME_LENGTH) {
                throw new DataProcessingException("Kullanıcı adı", "doğrulama",
                        "En fazla " + MAX_USERNAME_LENGTH + " karakter olabilir");
            }
            if (!username.matches("^[a-zA-Z0-9_-]+$")) {
                throw new DataProcessingException("Kullanıcı adı", "doğrulama",
                        "Sadece harf, rakam, _ ve - karakterleri içerebilir");
            }

            return username;

        } catch (Exception e) {
            throw new DataProcessingException("Kullanıcı adı", "doğrulama", e.getMessage());
        }
    }

    private String getValidatedPassword() throws WeatherException {
        try {
            if (passwordField == null) {
                throw new UIOperationException("PasswordField", "erişim", "Null referans");
            }

            String password = passwordField.getText();
            if (password == null) password = "";
            password = password.trim();

            if (password.isEmpty()) {
                throw new DataProcessingException("Şifre", "doğrulama", "Boş olamaz");
            }
            if (password.length() < MIN_PASSWORD_LENGTH) {
                throw new DataProcessingException("Şifre", "doğrulama",
                        "En az " + MIN_PASSWORD_LENGTH + " karakter olmalı");
            }

            return password;

        } catch (Exception e) {
            throw new DataProcessingException("Şifre", "doğrulama", e.getMessage());
        }
    }

    private void validateBusinessRules(String username) throws WeatherException {
        try {
            if (favoriteCities.isEmpty()) {
                throw new DataProcessingException("Favori konum", "kontrol", "En az bir favori konum eklemelisiniz");
            }

            if (findUser(username) != null) {
                throw new DataProcessingException("Kullanıcı adı", "kontrol", "Bu kullanıcı adı zaten kullanılıyor");
            }

        } catch (Exception e) {
            throw new DataProcessingException("İş kuralları", "doğrulama", e.getMessage());
        }
    }

    private User createNewUser(String username, String password) throws WeatherException {
        try {
            MyLinkedList<String> cityListCopy = new MyLinkedList<>();
            for (String city : favoriteCities) {
                cityListCopy.add(city);
            }

            User newUser = new User(username, password, false, cityListCopy);
            newUser.setRegistrationDate(LocalDateTime.now());
            newUser.setActive(true);

            return newUser;

        } catch (Exception e) {
            throw new DataProcessingException("Kullanıcı", "oluşturma", e.getMessage());
        }
    }

    private void completeRegistration(User newUser) throws WeatherException {
        try {
            users.add(newUser);

            showSuccess("🎉 Kayıt başarılı! Giriş yapabilirsiniz.");

            startLoginRedirectTimer();

        } catch (Exception e) {
            throw new DataProcessingException("Kayıt", "tamamlama", e.getMessage());
        }
    }

    private void startLoginRedirectTimer() {
        try {
            new Thread(() -> {
                try {
                    Thread.sleep(2000);
                    Platform.runLater(() -> {
                        try {
                            navigateToLogin();
                        } catch (Exception e) {
                            showError("Login ekranına geçişte hata: " + e.getMessage());
                        }
                    });
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        } catch (Exception e) {
            System.err.println("Login redirect timer hatası: " + e.getMessage());
        }
    }

    @FXML
    private void onBack() {
        try {
            navigateToLogin();
        } catch (WeatherException e) {
            showError("Geri dönüş hatası: " + e.getMessage());
        } catch (Exception e) {
            showError("Beklenmeyen geri dönüş hatası: " + e.getMessage());
        }
    }

    private void navigateToLogin() throws WeatherException {
        try {
            HelloFX.showLoginScreen();
        } catch (Exception e) {
            throw new UIOperationException("Login ekranı", "geçiş", e.getMessage());
        }
    }

    private User findUser(String username) {
        try {
            for (User u : users) {
                if (u != null && u.getUsername() != null && u.getUsername().equals(username)) {
                    return u;
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    private void handleCityError(String message) {
        showError(message);
    }

    private void handleRegistrationError(String message) {
        showError(message);
    }

    private void showError(String message) {
        try {
            updateErrorLabel(message, true);
            startMessageClearTimer(3000);
        } catch (Exception e) {
            System.err.println("Hata mesajı gösterilemedi: " + message);
        }
    }

    private void showSuccess(String message) {
        try {
            updateErrorLabel(message, false);
            startMessageClearTimer(2000);
        } catch (Exception e) {
            System.err.println("Başarı mesajı gösterilemedi: " + message);
        }
    }

    private void updateErrorLabel(String message, boolean isError) throws WeatherException {
        try {
            if (errorLabel == null) {
                throw new UIOperationException("ErrorLabel", "güncelleme", "Null referans");
            }

            if (isError) {
                errorLabel.setText("❌ " + message);
                errorLabel.setTextFill(Color.web("#FFCDD2"));
                errorLabel.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; " +
                        "-fx-background-color: rgba(244, 67, 54, 0.3); " +
                        "-fx-background-radius: 10; -fx-padding: 8;");
            } else {
                errorLabel.setText("✅ " + message);
                errorLabel.setTextFill(Color.web("#C8E6C9"));
                errorLabel.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; " +
                        "-fx-background-color: rgba(76, 175, 80, 0.3); " +
                        "-fx-background-radius: 10; -fx-padding: 8;");
            }

            errorLabel.setVisible(true);

        } catch (Exception e) {
            throw new UIOperationException("ErrorLabel", "güncelleme", e.getMessage());
        }
    }

    private void startMessageClearTimer(int delayMillis) {
        try {
            new Thread(() -> {
                try {
                    Thread.sleep(delayMillis);
                    Platform.runLater(() -> {
                        try {
                            if (errorLabel != null) {
                                errorLabel.setVisible(false);
                            }
                        } catch (Exception e) {
                            System.err.println("Mesaj temizlenemedi: " + e.getMessage());
                        }
                    });
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        } catch (Exception e) {
            System.err.println("Mesaj temizleme timer hatası: " + e.getMessage());
        }
    }

    public MyLinkedList<String> getFavoriteCities() {
        return favoriteCities;
    }

    public int getFavoriteCityCount() {
        try {
            return favoriteCities.size();
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean isCityCached(String cityName) {
        try {
            return validCityCache.get(cityName) != null;
        } catch (Exception e) {
            return false;
        }
    }

    public void clearFavoriteCities() throws WeatherException {
        try {
            favoriteCities.clear();
            citiesContainer.getChildren().clear();
        } catch (Exception e) {
            throw new DataProcessingException("Favori konumlar", "temizleme", e.getMessage());
        }
    }

    public void clearCityCache() {
        try {
            validCityCache.clear();
        } catch (Exception e) {
            System.err.println("Cache temizleme hatası: " + e.getMessage());
        }
    }
}