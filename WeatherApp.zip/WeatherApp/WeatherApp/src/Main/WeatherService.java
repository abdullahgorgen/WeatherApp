package Main;

import java.net.http.*;
import java.net.URI;

public class WeatherService {
    private static final String API_KEY = "819039aff951ff84881e092c47e9ec46";
    private static MyQueue<ApiRequest> requestQueue = new MyQueue<>();
    private static boolean isProcessingQueue = false;

    private static class ApiRequest {
        String type;
        String city;
        ApiCallback callback;

        ApiRequest(String type, String city, ApiCallback callback) {
            this.type = type;
            this.city = city;
            this.callback = callback;
        }
    }

    public interface ApiCallback {
        void onResult(Object result);
        void onError(String error);
    }

    private static void processApiQueue() {
        if (isProcessingQueue || requestQueue.isEmpty()) return;

        isProcessingQueue = true;
        new Thread(() -> {
            while (!requestQueue.isEmpty()) {
                ApiRequest request = requestQueue.dequeue();
                processApiRequest(request);

                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            isProcessingQueue = false;
        }).start();
    }

    private static void processApiRequest(ApiRequest request) {
        try {
            Object result = null;

            switch (request.type) {
                case "CURRENT":
                    result = fetchWeatherDirectly(request.city);
                    break;
                case "HOURLY":
                    result = fetchHourlyDirectly(request.city);
                    break;
                case "FORECAST":
                    result = fetchWeeklyFromForecastDirectly(request.city);
                    break;
                case "DISTRICT":
                    result = fetchDistrictWeatherDirectly(request.city);
                    break;
            }

            if (request.callback != null) {
                request.callback.onResult(result);
            }
        } catch (Exception e) {
            if (request.callback != null) {
                request.callback.onError(e.getMessage());
            }
        }
    }

    public static void fetchWeatherAsync(String city, ApiCallback callback) {
        requestQueue.enqueue(new ApiRequest("CURRENT", city, callback));
        processApiQueue();
    }

    public static void fetchHourlyAsync(String city, ApiCallback callback) {
        requestQueue.enqueue(new ApiRequest("HOURLY", city, callback));
        processApiQueue();
    }

    public static void fetchWeeklyAsync(String city, ApiCallback callback) {
        requestQueue.enqueue(new ApiRequest("FORECAST", city, callback));
        processApiQueue();
    }

    public static void fetchDistrictWeatherAsync(String city, ApiCallback callback) {
        requestQueue.enqueue(new ApiRequest("DISTRICT", city, callback));
        processApiQueue();
    }

    public static Weather fetchWeather(String city) {
        return fetchWeatherDirectly(city);
    }

    public static MyLinkedList<WeatherHourly> fetchHourly(String city) {
        return fetchHourlyDirectly(city);
    }

    public static MyLinkedList<WeatherDaily> fetchWeeklyFromForecast(String city) {
        return fetchWeeklyFromForecastDirectly(city);
    }

    public static MyLinkedList<District> fetchDistrictWeather(String city) {
        return fetchDistrictWeatherDirectly(city);
    }

    private static Weather fetchWeatherDirectly(String city) {
        String url = String.format(
                "https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric&lang=tr",
                city, API_KEY
        );
        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String json = response.body();

            double temp = 0.0;
            String desc = "";
            String icon = "";

            int tIdx = json.indexOf("\"temp\":");
            if (tIdx != -1) {
                String tStr = json.substring(tIdx + 7, json.indexOf(",", tIdx)).trim();
                temp = Double.parseDouble(tStr);
            }
            int dIdx = json.indexOf("\"description\":\"");
            if (dIdx != -1) {
                int dStart = dIdx + 15;
                int dEnd = json.indexOf("\"", dStart);
                desc = json.substring(dStart, dEnd);
            }
            int iIdx = json.indexOf("\"icon\":\"");
            if (iIdx != -1) {
                int iStart = iIdx + 8;
                int iEnd = json.indexOf("\"", iStart);
                icon = json.substring(iStart, iEnd);
            }

            return new Weather(temp, desc, icon);

        } catch (Exception e) {
            return new Weather(0, "API Hatası: " + e.getMessage(), "");
        }
    }

    private static MyLinkedList<WeatherHourly> fetchHourlyDirectly(String city) {
        MyLinkedList<WeatherHourly> result = new MyLinkedList<>();
        try {
            String url = String.format(
                    "https://api.openweathermap.org/data/2.5/forecast?q=%s&appid=%s&units=metric&lang=tr",
                    java.net.URLEncoder.encode(city, "UTF-8"), API_KEY
            );
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String json = response.body();

            int idx = 0;
            for (int count = 0; count < 8; count++) {
                idx = json.indexOf("\"dt_txt\":", idx);
                if (idx == -1) break;
                int start = json.indexOf("\"", idx + 9) + 1;
                int end = json.indexOf("\"", start);
                String dt = json.substring(start, end);
                String hour = dt.substring(11, 16);

                int tempIdx = json.indexOf("\"temp\":", idx);
                double temp = 0;
                if (tempIdx != -1) {
                    String tRest = json.substring(tempIdx + 7);
                    String tStr = tRest.substring(0, tRest.indexOf(",")).trim();
                    temp = Double.parseDouble(tStr);
                }

                int descIdx = json.indexOf("\"description\":\"", idx);
                String desc = "";
                if (descIdx != -1) {
                    int dStart = descIdx + 15;
                    int dEnd = json.indexOf("\"", dStart);
                    desc = json.substring(dStart, dEnd);
                }

                int iIdx = json.indexOf("\"icon\":\"", idx);
                String icon = "";
                if (iIdx != -1) {
                    int iStart = iIdx + 8;
                    int iEnd = json.indexOf("\"", iStart);
                    icon = json.substring(iStart, iEnd);
                }

                result.add(new WeatherHourly(hour, temp, desc, icon));
                idx = end;
            }
        } catch (Exception e) {
            System.out.println("Saatlik API HATASI: " + e.getMessage());
        }

        return result;
    }

    private static MyLinkedList<WeatherDaily> fetchWeeklyFromForecastDirectly(String city) {
        MyLinkedList<WeatherDaily> result = new MyLinkedList<>();
        try {
            String url = String.format(
                    "https://api.openweathermap.org/data/2.5/forecast?q=%s&appid=%s&units=metric&lang=tr",
                    java.net.URLEncoder.encode(city, "UTF-8"), API_KEY
            );
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String json = response.body();

            MyLinkedList<String> days = new MyLinkedList<>();
            MyLinkedList<MyLinkedList<Double>> minTemps = new MyLinkedList<>();
            MyLinkedList<MyLinkedList<Double>> maxTemps = new MyLinkedList<>();
            MyLinkedList<MyLinkedList<String>> descriptions = new MyLinkedList<>();

            int idx = 0;
            while ((idx = json.indexOf("\"dt_txt\":", idx)) != -1) {
                int start = json.indexOf("\"", idx + 9) + 1;
                int end = json.indexOf("\"", start);
                String dt = json.substring(start, end);
                String day = dt.substring(0, 10);

                int tempIdx = json.indexOf("\"temp\":", idx);
                double temp = 0;
                if (tempIdx != -1) {
                    String tRest = json.substring(tempIdx + 7);
                    String tStr = tRest.substring(0, tRest.indexOf(",")).trim();
                    temp = Double.parseDouble(tStr);
                }

                int descIdx = json.indexOf("\"description\":\"", idx);
                String desc = "";
                if (descIdx != -1) {
                    int dStart = descIdx + 15;
                    int dEnd = json.indexOf("\"", dStart);
                    desc = json.substring(dStart, dEnd);
                }

                int dayIndex = -1;
                for (int i = 0; i < days.size(); i++) {
                    if (days.get(i).equals(day)) {
                        dayIndex = i;
                        break;
                    }
                }

                if (dayIndex == -1) {
                    days.add(day);
                    minTemps.add(new MyLinkedList<>());
                    maxTemps.add(new MyLinkedList<>());
                    descriptions.add(new MyLinkedList<>());
                    dayIndex = days.size() - 1;
                }

                minTemps.get(dayIndex).add(temp);
                maxTemps.get(dayIndex).add(temp);
                descriptions.get(dayIndex).add(desc);

                idx = end;
            }

            for (int i = 0; i < days.size() && result.size() < 5; i++) {
                String day = days.get(i);
                MyLinkedList<Double> temps = minTemps.get(i);
                MyLinkedList<String> descList = descriptions.get(i);

                double minTemp = Double.MAX_VALUE;
                double maxTemp = Double.MIN_VALUE;
                for (Double t : temps) {
                    if (t < minTemp) minTemp = t;
                    if (t > maxTemp) maxTemp = t;
                }

                String mostCommonDesc = "";
                int maxCount = 0;
                for (String desc : descList) {
                    int count = 0;
                    for (String d : descList) {
                        if (d.equals(desc)) count++;
                    }
                    if (count > maxCount) {
                        maxCount = count;
                        mostCommonDesc = desc;
                    }
                }

                result.add(new WeatherDaily(day, minTemp, maxTemp, mostCommonDesc, ""));
            }

        } catch (Exception e) {
            System.out.println("Haftalık (forecast) API hatası: " + e.getMessage());
        }
        return result;
    }

    private static MyLinkedList<District> fetchDistrictWeatherDirectly(String cityName) {
        MyLinkedList<District> districts = new MyLinkedList<>();

        try {
            String geocodingUrl = String.format(
                    "http://api.openweathermap.org/geo/1.0/direct?q=%s&limit=1&appid=%s",
                    java.net.URLEncoder.encode(cityName, "UTF-8"), API_KEY
            );

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(geocodingUrl)).build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String json = response.body();

            double lat = parseJsonDouble(json, "lat");
            double lon = parseJsonDouble(json, "lon");

            if (lat == 0 && lon == 0) {
                Weather cityWeather = fetchWeatherDirectly(cityName);
                districts.add(new District("Merkez", cityName,
                        cityWeather.getTemperature(),
                        cityWeather.getDescription(),
                        cityWeather.getIcon()));
                return districts;
            }

            Weather centerWeather = fetchWeatherByCoordinates(lat, lon);
            districts.add(new District(cityName + " Merkez", cityName,
                    centerWeather.getTemperature(),
                    centerWeather.getDescription(),
                    centerWeather.getIcon()));

            double radius = 0.08;
            String[] directions = {"Kuzey", "Kuzeydoğu", "Doğu", "Güneydoğu",
                    "Güney", "Güneybatı", "Batı", "Kuzeybatı"};

            for (int i = 0; i < 8; i++) {
                double angle = (2 * Math.PI * i) / 8;
                double newLat = lat + radius * Math.cos(angle);
                double newLon = lon + radius * Math.sin(angle);

                Weather weather = fetchWeatherByCoordinates(newLat, newLon);
                districts.add(new District(
                        cityName + " " + directions[i],
                        cityName,
                        weather.getTemperature(),
                        weather.getDescription(),
                        weather.getIcon()
                ));

                Thread.sleep(150);
            }

        } catch (Exception e) {
            System.out.println("İlçe hava durumu hatası: " + e.getMessage());
        }

        return districts;
    }

    private static Weather fetchWeatherByCoordinates(double lat, double lon) {
        try {
            String url = String.format(
                    "https://api.openweathermap.org/data/2.5/weather?lat=%.4f&lon=%.4f&appid=%s&units=metric&lang=tr",
                    lat, lon, API_KEY
            );

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(url)).build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String json = response.body();

            double temp = parseJsonDouble(json, "temp");
            String desc = parseJsonString(json, "description");
            String icon = parseJsonString(json, "icon");

            return new Weather(temp, desc, icon);

        } catch (Exception e) {
            return new Weather(0, "Veri Alınamadı", "");
        }
    }

    private static double parseJsonDouble(String json, String key) {
        try {
            int idx = json.indexOf("\"" + key + "\":");
            if (idx == -1) return 0.0;
            String rest = json.substring(idx + key.length() + 3);
            String numStr = rest.substring(0, rest.indexOf(",")).trim();
            return Double.parseDouble(numStr);
        } catch (Exception e) {
            return 0.0;
        }
    }

    private static String parseJsonString(String json, String key) {
        try {
            int idx = json.indexOf("\"" + key + "\":\"");
            if (idx == -1) return "";
            int start = idx + key.length() + 4;
            int end = json.indexOf("\"", start);
            return json.substring(start, end);
        } catch (Exception e) {
            return "";
        }
    }

    public static int getQueueSize() {
        return requestQueue.size();
    }

    public static boolean isQueueProcessing() {
        return isProcessingQueue;
    }
}