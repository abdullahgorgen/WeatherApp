package Main;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class WeeklyWeatherController {

    @FXML private Label cityLabel;
    @FXML private HBox weeklyCardsContainer;

    private String city;
    private final MyLinkedList<WeatherDaily> weatherCache = new MyLinkedList<>();

    public void setCity(String city) {
        try {
            if (city == null || city.trim().isEmpty()) {
                throw new InvalidCityNameException("Boş şehir adı");
            }

            this.city = city;
            if (cityLabel != null) {
                cityLabel.setText(city + " için 5 Günlük Hava Durumu");
            }

            loadWeeklyWeather();
        } catch (WeatherException e) {
            showErrorAlert("Şehir Hatası", e.getMessage());
        } catch (Exception e) {
            showErrorAlert("Sistem Hatası", "Beklenmeyen hata: " + e.getMessage());
        }
    }

    private void loadWeeklyWeather() {
        new Thread(() -> {
            try {
                MyLinkedList<WeatherDaily> weeklyData = fetchWeeklyData();

                Platform.runLater(() -> {
                    try {
                        displayWeeklyCards(weeklyData);
                    } catch (WeatherException e) {
                        showErrorAlert("Görüntüleme Hatası", e.getMessage());
                    }
                });

            } catch (WeatherException e) {
                Platform.runLater(() -> showErrorAlert("Veri Yükleme Hatası", e.getMessage()));
            }
        }).start();
    }

    private MyLinkedList<WeatherDaily> fetchWeeklyData() throws WeatherException {
        try {
            MyLinkedList<WeatherDaily> weeklyData = WeatherService.fetchWeeklyFromForecast(city);

            if (weeklyData == null || weeklyData.isEmpty()) {
                throw new WeatherDataNotFoundException(city, "Haftalık veri bulunamadı");
            }

            return weeklyData;
        } catch (Exception e) {
            throw new WeatherServiceException("haftalık veri alma", e.getMessage());
        }
    }

    private void displayWeeklyCards(MyLinkedList<WeatherDaily> weeklyData) throws WeatherException {
        try {
            if (weeklyCardsContainer == null) {
                throw new UIOperationException("WeeklyCardsContainer", "erişim", "Null referans");
            }

            weeklyCardsContainer.getChildren().clear();
            weatherCache.clear();

            for (WeatherDaily weather : weeklyData) {
                if (weather != null) {
                    weatherCache.add(weather);
                    VBox dayCard = createDayCard(weather);
                    weeklyCardsContainer.getChildren().add(dayCard);
                }
            }
        } catch (Exception e) {
            throw new UIOperationException("Haftalık kartlar", "görüntüleme", e.getMessage());
        }
    }

    private VBox createDayCard(WeatherDaily weatherDaily) throws WeatherException {
        try {
            VBox card = new VBox();
            card.setAlignment(javafx.geometry.Pos.CENTER);
            card.setSpacing(10);
            card.setPrefWidth(130);
            card.setPrefHeight(180);
            card.setStyle(
                    "-fx-background-color: rgba(255, 255, 255, 0.25); " +
                            "-fx-background-radius: 15; " +
                            "-fx-padding: 15; " +
                            "-fx-cursor: hand; " +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 5, 0, 0, 2);"
            );

            setupCardHoverEffects(card);
            card.setOnMouseClicked(e -> {
                try {
                    showDayDetails(weatherDaily.getDay());
                } catch (Exception ex) {
                    showErrorAlert("Detay Hatası", "Günlük detay açılamadı: " + ex.getMessage());
                }
            });

            Label dayLabel = createDayLabel(weatherDaily.getDay());
            ImageView iconView = createWeatherIcon(weatherDaily);
            Label tempLabel = createTemperatureLabel(weatherDaily.getAvgTemp());
            Label minMaxLabel = createMinMaxLabel(weatherDaily);
            Label descLabel = createDescriptionLabel(weatherDaily.getDescription());

            card.getChildren().addAll(dayLabel, iconView, tempLabel, minMaxLabel, descLabel);
            return card;

        } catch (Exception e) {
            throw new UIOperationException("Günlük kart", "oluşturma", e.getMessage());
        }
    }

    private void setupCardHoverEffects(VBox card) {
        String normalStyle = "-fx-background-color: rgba(255, 255, 255, 0.25); " +
                "-fx-background-radius: 15; " +
                "-fx-padding: 15; " +
                "-fx-cursor: hand; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 5, 0, 0, 2);";

        String hoverStyle = "-fx-background-color: rgba(255, 255, 255, 0.35); " +
                "-fx-background-radius: 15; " +
                "-fx-padding: 15; " +
                "-fx-cursor: hand; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.3), 8, 0, 0, 4);";

        card.setOnMouseEntered(e -> card.setStyle(hoverStyle));
        card.setOnMouseExited(e -> card.setStyle(normalStyle));
    }

    private Label createDayLabel(String dateString) {
        String dayName = getDayName(dateString);
        Label dayLabel = new Label(dayName);
        dayLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14px; -fx-font-weight: bold;");
        return dayLabel;
    }

    private ImageView createWeatherIcon(WeatherDaily weatherDaily) {
        String iconPath = WeatherIcons.iconFor(weatherDaily.getDescription(), weatherDaily.getIcon());
        ImageView iconView = new ImageView();
        try {
            Image icon = new Image(getClass().getResourceAsStream(iconPath));
            iconView.setImage(icon);
            iconView.setFitWidth(50);
            iconView.setFitHeight(50);
            iconView.setPreserveRatio(true);
        } catch (Exception e) {
            iconView.setFitWidth(50);
            iconView.setFitHeight(50);
        }
        return iconView;
    }

    private Label createTemperatureLabel(double temperature) {
        String tempText = String.format("%.0f°C", temperature);
        Label tempLabel = new Label(tempText);
        tempLabel.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");
        return tempLabel;
    }

    private Label createMinMaxLabel(WeatherDaily weatherDaily) {
        String minMaxText = String.format("%.0f°/%.0f°", weatherDaily.getMinTemp(), weatherDaily.getMaxTemp());
        Label minMaxLabel = new Label(minMaxText);
        minMaxLabel.setStyle("-fx-text-fill: rgba(255,255,255,0.8); -fx-font-size: 11px;");
        return minMaxLabel;
    }

    private Label createDescriptionLabel(String description) {
        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-text-fill: rgba(255,255,255,0.9); -fx-font-size: 10px; -fx-text-alignment: center;");
        descLabel.setWrapText(true);
        descLabel.setMaxWidth(110);
        return descLabel;
    }

    private String getDayName(String dateString) {
        try {
            LocalDate date = LocalDate.parse(dateString);
            String dayName = date.format(DateTimeFormatter.ofPattern("EEE")).toLowerCase();

            switch (dayName) {
                case "mon": return "PZT";
                case "tue": return "SAL";
                case "wed": return "ÇAR";
                case "thu": return "PER";
                case "fri": return "CUM";
                case "sat": return "CTS";
                case "sun": return "PAZ";
                default: return dayName.toUpperCase().substring(0, 3);
            }
        } catch (Exception e) {
            return dateString.length() > 10 ? dateString.substring(5, 10) : dateString;
        }
    }

    private void showDayDetails(String selectedDate) throws WeatherException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main/DailyDetails.fxml"));
            Parent root = loader.load();

            DailyDetailsController controller = loader.getController();
            controller.setCityAndDate(city, selectedDate);

            Stage stage = new Stage();
            stage.setTitle(city + " - " + selectedDate + " Saatlik Detay");
            stage.setScene(new Scene(root));
            stage.centerOnScreen();
            stage.show();

        } catch (Exception e) {
            throw new UIOperationException("Günlük detay", "açma", e.getMessage());
        }
    }

    @FXML
    private void onBack() {
        try {
            HelloFX.showMainScreen();
        } catch (Exception e) {
            showErrorAlert("Navigasyon Hatası", "Ana ekrana dönülürken hata: " + e.getMessage());
        }
    }

    private void showErrorAlert(String title, String message) {
        try {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText("Haftalık Hava Durumu Hatası");
            alert.setContentText(message);
            alert.showAndWait();
        } catch (Exception e) {
            System.err.println("Alert gösterilemedi: " + title + " - " + message);
        }
    }

    public MyLinkedList<WeatherDaily> getWeatherCache() {
        return weatherCache;
    }

    public WeatherDaily getCachedWeather(String date) {
        try {
            for (WeatherDaily weather : weatherCache) {
                if (weather != null && weather.getDay().equals(date)) {
                    return weather;
                }
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    public String getCurrentCity() {
        return city;
    }

    public int getWeatherCacheSize() {
        try {
            return weatherCache.size();
        } catch (Exception e) {
            return 0;
        }
    }
}