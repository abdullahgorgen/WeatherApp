package Main;

public class WeatherDaily {
    private String dayName;
    private double minTemp;
    private double maxTemp;
    private String description;
    private String icon;

    public WeatherDaily(String dayName, double minTemp, double maxTemp, String description, String icon) {
        this.dayName = dayName;
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.description = description;
        this.icon = icon;
    }
    public double getAvgTemp() {
        return (getMinTemp() + getMaxTemp()) / 2.0;
    }



    public String getDay() { return dayName; }
    public double getMinTemp() { return minTemp; }
    public double getMaxTemp() { return maxTemp; }
    public String getDescription() { return description; }
    public String getIcon() { return icon; }

    @Override
    public String toString() {
        String emoji = WeatherIcons.iconFor(description , icon);
        return String.format("%s: %s %s | Min: %.1f°C Max: %.1f°C",
                dayName, description, emoji, minTemp, maxTemp);
    }
}
