package Main;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainController {

    @FXML private TextField cityInput;
    @FXML private ListView<String> historyList;
    @FXML private ListView<String> favoriteList;
    @FXML private Label cityLabel;
    @FXML private ImageView weatherIconImageView;
    @FXML private Label descLabel;
    @FXML private Label tempLabel;

    @FXML private ListView<User> userManagementList;
    @FXML private Button deleteUserButton;
    @FXML private Button toggleAdminButton;
    @FXML private Label adminPanelLabel;
    @FXML private VBox adminPanel;

    private static final MyStack<String> searchStack = new MyStack<>();
    private final MyLinkedList<String> favorites = new MyLinkedList<>();
    private final MyBST<String, Boolean> validCityCache = new MyBST<>();
    private final MyLinkedList<String> searchHistory = new MyLinkedList<>();

    // Yeni eklenen BST - şehir adı ve favori durumu için
    private final MyBST<String, String> favoritesBST = new MyBST<>();

    private MyLinkedList<User> allUsers;
    private boolean isCurrentUserAdmin = false;

    @FXML
    public void initialize() {
        try {
            setupUI();
            setupUserData();
            setupEventHandlers();
        } catch (Exception e) {
            showAlert("Başlatma Hatası", "Uygulama başlatılırken hata: " + e.getMessage());
        }
    }

    private void setupUI() {
        try {
            if (weatherIconImageView != null) {
                weatherIconImageView.setOnMouseClicked(this::onWeatherIconClicked);
            }
            loadSearchHistory();
        } catch (Exception e) {
            System.err.println("UI kurulum hatası: " + e.getMessage());
        }
    }

    private void setupUserData() {
        try {
            User currentUser = HelloFX.getCurrentUser();
            isCurrentUserAdmin = currentUser != null && currentUser.isAdmin();

            if (isCurrentUserAdmin) {
                initializeAdminPanel();
            } else {
                hideAdminPanel();
            }

            loadUserFavorites(currentUser);
        } catch (Exception e) {
            System.err.println("Kullanıcı verisi kurulum hatası: " + e.getMessage());
        }
    }

    private void loadUserFavorites(User currentUser) {
        if (currentUser != null && currentUser.getFavoriteCities() != null) {
            favorites.clear();
            favoritesBST.clear();

            // Duplicate temizleme - sadece unique şehirleri ekle
            MyLinkedList<String> uniqueCities = new MyLinkedList<>();

            for (String city : currentUser.getFavoriteCities()) {
                if (!uniqueCities.contains(city)) {
                    uniqueCities.add(city);
                    favorites.add(city);
                    favoritesBST.put(city, city);
                }
            }

            // User'daki listeyi de temizle ve unique olanları geri yaz
            currentUser.getFavoriteCities().clear();
            for (String city : uniqueCities) {
                currentUser.getFavoriteCities().add(city);
            }

            Platform.runLater(() -> {
                updateFavoritesList();
                if (!favorites.isEmpty()) {
                    String firstCity = favorites.get(0);
                    if (favoriteList != null) {
                        favoriteList.getSelectionModel().select(firstCity);
                    }
                    showWeather(firstCity);
                }
            });
        }
    }

    private volatile boolean isUpdatingList = false;

    private void setupEventHandlers() {
        if (favoriteList != null) {
            favoriteList.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
                if (newVal != null && !newVal.isEmpty() && !isUpdatingList) {
                    moveToTop(newVal);
                    showWeather(newVal);
                }
            });
        }

        if (historyList != null) {
            historyList.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2) {
                    String selectedCity = historyList.getSelectionModel().getSelectedItem();
                    if (selectedCity != null) {
                        showWeather(selectedCity);
                    }
                }
            });

            // Tek tıklama ile seçim
            historyList.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
                if (newVal != null && !newVal.isEmpty()) {
                    showWeather(newVal);
                }
            });
        }

        setupHistoryContextMenu();
    }

    private void moveToTop(String cityName) {
        try {
            if (cityName == null || cityName.isEmpty()) return;

            // Favori listesinden güncelle
            favorites.remove(cityName);
            favorites.add(0, cityName);

            // BST'de güncelleme yap - zaten var ise value'yu aynı tutar
            favoritesBST.put(cityName, cityName);

            User currentUser = HelloFX.getCurrentUser();
            if (currentUser != null && currentUser.getFavoriteCities() != null) {
                currentUser.getFavoriteCities().remove(cityName);
                currentUser.getFavoriteCities().add(0, cityName);
            }

            Platform.runLater(() -> {
                updateFavoritesList();
                favoriteList.getSelectionModel().select(cityName);
            });

        } catch (Exception e) {
            System.err.println("Favori sıralama hatası: " + e.getMessage());
        }
    }

    private void initializeAdminPanel() {
        try {
            if (adminPanel != null) {
                adminPanel.setVisible(true);
                adminPanel.setManaged(true);
            }

            if (adminPanelLabel != null) {
                adminPanelLabel.setText("👑 Admin Paneli");
            }

            loadAllUsers();
            setupAdminControls();

            if (userManagementList != null) {
                userManagementList.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
                    updateAdminButtons(newVal);
                });
            }
        } catch (Exception e) {
            showAlert("Admin Panel Hatası", "Admin paneli başlatılamadı: " + e.getMessage());
        }
    }

    private void hideAdminPanel() {
        if (adminPanel != null) {
            adminPanel.setVisible(false);
            adminPanel.setManaged(false);
        }
    }

    private void loadAllUsers() {
        try {
            allUsers = LoginController.getUsersList();
            updateUserManagementList();
        } catch (Exception e) {
            showAlert("Admin Hatası", "Kullanıcılar yüklenemedi: " + e.getMessage());
        }
    }

    private void updateUserManagementList() {
        if (userManagementList == null) return;

        Platform.runLater(() -> {
            try {
                userManagementList.getItems().clear();
                for (User user : allUsers) {
                    if (user != null && user.isActive()) {
                        userManagementList.getItems().add(user);
                    }
                }
            } catch (Exception e) {
                showAlert("Admin Hatası", "Kullanıcı listesi güncellenemedi: " + e.getMessage());
            }
        });
    }

    private void setupAdminControls() {
        if (deleteUserButton != null) {
            deleteUserButton.setOnAction(e -> onDeleteUser());
        }
        if (toggleAdminButton != null) {
            toggleAdminButton.setOnAction(e -> onToggleAdmin());
        }
    }

    private void updateAdminButtons(User selectedUser) {
        boolean hasSelection = selectedUser != null;
        boolean canModify = hasSelection && !selectedUser.equals(HelloFX.getCurrentUser());

        if (deleteUserButton != null) {
            deleteUserButton.setDisable(!canModify);
        }

        if (toggleAdminButton != null) {
            toggleAdminButton.setDisable(!canModify);
            if (hasSelection && canModify) {
                toggleAdminButton.setText(selectedUser.isAdmin() ? "Admin Yetkisini Al" : "Admin Yap");
            }
        }
    }

    @FXML
    private void onDeleteUser() {
        try {
            User selectedUser = userManagementList.getSelectionModel().getSelectedItem();
            if (selectedUser == null) {
                showAlert("Uyarı", "Lütfen silinecek kullanıcıyı seçin!");
                return;
            }

            if (selectedUser.equals(HelloFX.getCurrentUser())) {
                throw new DataProcessingException("Kullanıcı silme", "işlem", "Kendi hesabınızı silemezsiniz");
            }

            confirmAndDeleteUser(selectedUser);
        } catch (WeatherException e) {
            showAlert("Admin Hatası", e.getMessage());
        } catch (Exception e) {
            showAlert("Sistem Hatası", "Kullanıcı silinemedi: " + e.getMessage());
        }
    }

    private void confirmAndDeleteUser(User selectedUser) {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Kullanıcı Silme Onayı");
        confirmAlert.setHeaderText("Kullanıcı Silinecek");
        confirmAlert.setContentText("'" + selectedUser.getUsername() + "' kullanıcısını silmek istediğinizden emin misiniz?\n\nBu işlem geri alınamaz!");

        ButtonType yesButton = new ButtonType("Evet, Sil", ButtonBar.ButtonData.YES);
        ButtonType noButton = new ButtonType("İptal", ButtonBar.ButtonData.NO);
        confirmAlert.getButtonTypes().setAll(yesButton, noButton);

        confirmAlert.showAndWait().ifPresent(response -> {
            if (response == yesButton) {
                try {
                    allUsers.remove(selectedUser);
                    updateUserManagementList();
                    showAlert("Başarılı", selectedUser.getUsername() + " kullanıcısı silindi!");
                } catch (Exception e) {
                    showAlert("Hata", "Kullanıcı silinirken hata: " + e.getMessage());
                }
            }
        });
    }

    @FXML
    private void onToggleAdmin() {
        try {
            User selectedUser = validateAdminSelection();

            boolean newAdminStatus = !selectedUser.isAdmin();
            selectedUser.setAdmin(newAdminStatus);

            String message = newAdminStatus ?
                    selectedUser.getUsername() + " artık admin!" :
                    selectedUser.getUsername() + " artık normal kullanıcı!";

            updateUserManagementList();
            updateAdminButtons(selectedUser);
            showAlert("Başarılı", message);
        } catch (WeatherException e) {
            showAlert("Admin Hatası", e.getMessage());
        } catch (Exception e) {
            showAlert("Sistem Hatası", "Admin durumu değiştirilemedi: " + e.getMessage());
        }
    }

    private User validateAdminSelection() throws WeatherException {
        if (userManagementList == null) {
            throw new UIOperationException("Kullanıcı listesi", "doğrulama", "Kullanıcı listesi bulunamadı");
        }

        User selectedUser = userManagementList.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            throw new DataProcessingException("Kullanıcı seçimi", "doğrulama", "Lütfen bir kullanıcı seçin");
        }

        if (selectedUser.equals(HelloFX.getCurrentUser())) {
            throw new DataProcessingException("Kullanıcı düzenleme", "işlem", "Kendi hesabınızı düzenleyemezsiniz");
        }

        return selectedUser;
    }

    private boolean isValidCity(String cityName) {
        try {
            Boolean cachedResult = validCityCache.get(cityName);
            if (cachedResult != null) {
                return cachedResult;
            }

            Weather weather = WeatherService.fetchWeather(cityName);
            boolean isValid = weather != null &&
                    weather.getTemperature() != 0.0 &&
                    !weather.getDescription().toLowerCase().contains("not found");

            validCityCache.put(cityName, isValid);
            return isValid;
        } catch (Exception e) {
            try {
                validCityCache.put(cityName, false);
            } catch (Exception ignored) {}
            return false;
        }
    }

    @FXML
    private void onSearch() {
        try {
            String city = validateCityInput();

            if (!isValidCity(city)) {
                throw new InvalidCityNameException(city);
            }

            searchStack.push(city);

            Platform.runLater(() -> {
                if (historyList != null) {
                    searchHistory.remove(city);
                    searchHistory.add(0, city);

                    historyList.getItems().remove(city);
                    historyList.getItems().add(0, city);
                }
            });

            showWeather(city);
            if (cityInput != null) {
                cityInput.clear();
            }
        } catch (WeatherException e) {
            showAlert("Konum Hatası", e.getMessage());
        } catch (Exception e) {
            showAlert("Arama Hatası", "Konum araması yapılamadı: " + e.getMessage());
        }
    }

    @FXML
    private void onFavorite() {
        try {
            String city = validateCityInput();
            addToFavorites(city);
        } catch (WeatherException e) {
            showAlert("Favori Konum Hatası", e.getMessage());
        } catch (Exception e) {
            showAlert("Sistem Hatası", "Favori konum eklenemedi: " + e.getMessage());
        }
    }

    private String validateCityInput() throws InvalidCityNameException {
        if (cityInput == null) {
            throw new InvalidCityNameException("Konum giriş alanı bulunamadı");
        }

        String city = cityInput.getText().trim();
        if (city.isEmpty()) {
            throw new InvalidCityNameException("Lütfen bir konum adı girin");
        }

        return city;
    }

    private void addToFavorites(String city) throws WeatherException {
        try {
            // Önce completely temizle - hem BST hem LinkedList
            cleanupDuplicateCity(city);

            if (!isValidCity(city)) {
                throw new InvalidCityNameException("Geçersiz konum adı: " + city);
            }

            // BST kontrol et
            if (favoritesBST.containsKey(city)) {
                moveToTop(city);
                showAlert("Bilgi", city + " zaten favori konumlarınızda - en başa taşındı! ⭐");
                return;
            }

            // Temiz ekleme
            favorites.add(0, city);
            favoritesBST.put(city, city);

            User currentUser = HelloFX.getCurrentUser();
            if (currentUser != null && currentUser.getFavoriteCities() != null) {
                currentUser.getFavoriteCities().add(0, city);
            }

            updateFavoritesList();

            Platform.runLater(() -> {
                if (favoriteList != null) {
                    favoriteList.getSelectionModel().select(0); // İlk indeksi seç
                }
            });

            showAlert("Başarılı", city + " favori konumlarınıza eklendi! ⭐");
        } catch (Exception e) {
            throw new DataProcessingException("Favori konum", "ekleme", e.getMessage());
        }
    }

    // Duplicate city temizleme helper method
    private void cleanupDuplicateCity(String city) {
        try {
            // LinkedList'ten tüm kopyaları sil
            int removedCount = 0;
            while (favorites.contains(city)) {
                favorites.remove(city);
                removedCount++;
            }

            // User data'dan da temizle
            User currentUser = HelloFX.getCurrentUser();
            if (currentUser != null && currentUser.getFavoriteCities() != null) {
                while (currentUser.getFavoriteCities().contains(city)) {
                    currentUser.getFavoriteCities().remove(city);
                }
            }

            // Debug için
            if (removedCount > 0) {
                System.out.println("Temizlenen duplicate şehir: " + city + " (Adet: " + removedCount + ")");
            }
        } catch (Exception e) {
            System.err.println("Cleanup hatası: " + e.getMessage());
        }
    }

    private void removeFromFavorites(String city) {
        try {
            // BST ile kontrol et
            if (!favoritesBST.containsKey(city)) {
                showAlert("Bilgi", city + " favori konumlarınızda bulunamadı!");
                return;
            }

            Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
            confirmAlert.setTitle("Favori Konum Silme Onayı");
            confirmAlert.setHeaderText("Favori Konum Silinecek");
            confirmAlert.setContentText(city + " konumunu favori konumlarınızdan silmek istediğinizden emin misiniz?");

            ButtonType yesButton = new ButtonType("Evet", ButtonBar.ButtonData.YES);
            ButtonType noButton = new ButtonType("Hayır", ButtonBar.ButtonData.NO);
            confirmAlert.getButtonTypes().setAll(yesButton, noButton);

            confirmAlert.showAndWait().ifPresent(response -> {
                if (response == yesButton) {
                    try {
                        // Hem LinkedList hem BST'den sil
                        favorites.remove(city);
                        favoritesBST.remove(city);

                        User currentUser = HelloFX.getCurrentUser();
                        if (currentUser != null) {
                            currentUser.getFavoriteCities().remove(city);
                        }
                        updateFavoritesList();
                        showAlert("Başarılı", city + " favori konumlarınızdan silindi! 🗑");
                    } catch (Exception e) {
                        showAlert("Hata", "Favori konum silinirken hata: " + e.getMessage());
                    }
                }
            });
        } catch (Exception e) {
            showAlert("Favori Konum Hatası", "Favori konum silinemedi: " + e.getMessage());
        }
    }

    // Favorileri kontrol eden yardımcı method
    private boolean isCityInFavorites(String city) {
        return favoritesBST.containsKey(city);
    }

    // Tüm favori şehirleri BST'den al
    private MyLinkedList<String> getAllFavoriteCities() {
        return favoritesBST.keys();
    }

    @FXML
    private void onShowWeekly() {
        try {
            String selectedCity = getValidatedSelectedCity();
            openWeeklyWeatherWindow(selectedCity);
        } catch (WeatherException e) {
            showAlert("Haftalık Görünüm Hatası", e.getMessage());
        } catch (Exception e) {
            showAlert("Sistem Hatası", "Haftalık hava durumu açılamadı: " + e.getMessage());
        }
    }

    @FXML
    private void onShowGraph() {
        try {
            String selectedCity = getValidatedSelectedCity();
            openGraphVisualizationWindow(selectedCity);
        } catch (WeatherException e) {
            showAlert("Graph Görünüm Hatası", e.getMessage());
        } catch (Exception e) {
            showAlert("Sistem Hatası", "Graph görselleştirme açılamadı: " + e.getMessage());
        }
    }

    private String getValidatedSelectedCity() throws InvalidCityNameException {
        String selectedCity = getCurrentDisplayedCity(); // Bu değişiklik
        if (selectedCity == null) {
            throw new InvalidCityNameException("Konum seçilmemiş - lütfen bir konum seçin");
        }

        if (!isValidCity(selectedCity)) {
            throw new InvalidCityNameException("Seçilen konum geçersiz: " + selectedCity);
        }

        return selectedCity;
    }

    private void openWeeklyWeatherWindow(String city) throws WeatherException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main/WeeklyWeather.fxml"));
            Parent root = loader.load();
            WeeklyWeatherController controller = loader.getController();
            controller.setCity(city);
            HelloFX.getMainStage().setScene(new Scene(root));
        } catch (Exception e) {
            throw new UIOperationException("Haftalık hava durumu", "açma", e.getMessage());
        }
    }

    private void openGraphVisualizationWindow(String city) throws WeatherException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main/GraphVisualization.fxml"));
            Parent root = loader.load();
            GraphVisualizationController controller = loader.getController();
            controller.setCity(city);
            HelloFX.getMainStage().setScene(new Scene(root));
        } catch (Exception e) {
            throw new UIOperationException("Graph görselleştirme", "açma", e.getMessage());
        }
    }

    private void onWeatherIconClicked(MouseEvent event) {
        try {
            if (cityLabel == null) {
                throw new UIOperationException("Konum label", "erişim", "Konum bilgisi bulunamadı");
            }

            String city = cityLabel.getText().replace(" için Hava Durumu", "").trim();

            if (!isValidCity(city)) {
                throw new InvalidCityNameException("Seçilen konum geçersiz: " + city);
            }

            openHourlyWeatherWindow(city);
        } catch (WeatherException e) {
            showAlert("Saatlik Görünüm Hatası", e.getMessage());
        } catch (Exception e) {
            showAlert("Sistem Hatası", "Saatlik hava durumu açılamadı: " + e.getMessage());
        }
    }

    private void openHourlyWeatherWindow(String city) throws WeatherException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main/HourlyWeather.fxml"));
            Parent root = loader.load();
            HourlyWeatherController controller = loader.getController();
            controller.setCity(city);

            Stage stage = new Stage();
            stage.setTitle(city + " - Saatlik Hava Durumu");
            stage.setScene(new Scene(root));
            stage.centerOnScreen();
            stage.show();
        } catch (Exception e) {
            throw new UIOperationException("Saatlik hava durumu", "açma", e.getMessage());
        }
    }

    @FXML
    private void onExit() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Main/Login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) cityInput.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            showAlert("Çıkış Hatası", "Login ekranına dönülürken hata: " + e.getMessage());
            Platform.exit();
        }
    }

    private void setupHistoryContextMenu() {
        if (historyList != null && favoriteList != null) {
        }
    }

    private void loadSearchHistory() {
        Platform.runLater(() -> {
            if (historyList != null) {
                historyList.getItems().clear();
                for (String city : searchHistory) {
                    historyList.getItems().add(city);
                }
            }
        });
    }

    private void updateFavoritesList() {
        Platform.runLater(() -> {
            if (favoriteList != null && !isUpdatingList) {
                isUpdatingList = true;
                try {
                    String selectedCity = null;
                    if (favoriteList.getSelectionModel().getSelectedItem() != null) {
                        selectedCity = favoriteList.getSelectionModel().getSelectedItem();
                    }

                    favoriteList.getItems().clear();
                    for (String city : favorites) {
                        favoriteList.getItems().add(city);
                    }

                    // Seçimi geri yükle (eğer hala listede varsa)
                    if (selectedCity != null && favorites.contains(selectedCity)) {
                        favoriteList.getSelectionModel().select(selectedCity);
                    }
                } finally {
                    isUpdatingList = false;
                }
            }
        });
    }

    private String getSelectedCity() {
        // Önce favorilerden seçileni kontrol et
        if (favoriteList != null && favoriteList.getSelectionModel().getSelectedItem() != null) {
            return favoriteList.getSelectionModel().getSelectedItem();
        }
        // Sonra geçmişten seçileni kontrol et
        else if (historyList != null && historyList.getSelectionModel().getSelectedItem() != null) {
            return historyList.getSelectionModel().getSelectedItem();
        }
        // Son arama yapılan şehir
        else if (!searchStack.isEmpty()) {
            return searchStack.peek();
        }
        // En son favoriye eklenen şehir
        else if (!favorites.isEmpty()) {
            return favorites.get(0);
        }
        return null;
    }

    // Haftalık ve grafik için kullanılacak method
    private String getCurrentDisplayedCity() {
        if (cityLabel != null && cityLabel.getText() != null) {
            String cityFromLabel = cityLabel.getText().replace(" için Hava Durumu", "").trim();
            if (!cityFromLabel.isEmpty() && !cityFromLabel.equals("için Hava Durumu")) {
                return cityFromLabel;
            }
        }
        return getSelectedCity();
    }

    // Thread pool for weather requests
    private static final ExecutorService weatherExecutor = Executors.newFixedThreadPool(3);
    private volatile String currentWeatherCity = null;

    private void showWeather(String city) {
        if (city == null || city.equals(currentWeatherCity)) return;

        currentWeatherCity = city;

        if (cityLabel != null) cityLabel.setText(city + " için Hava Durumu");
        if (descLabel != null) descLabel.setText("Yükleniyor...");
        if (tempLabel != null) tempLabel.setText("");
        if (weatherIconImageView != null) weatherIconImageView.setImage(null);

        weatherExecutor.submit(() -> {
            try {
                if (!city.equals(currentWeatherCity)) return; // Request cancelled

                Weather weather = WeatherService.fetchWeather(city);

                if (city.equals(currentWeatherCity)) { // Still current request
                    Platform.runLater(() -> updateWeatherDisplay(weather));
                }
            } catch (Exception e) {
                if (city.equals(currentWeatherCity)) {
                    Platform.runLater(() -> {
                        if (descLabel != null) descLabel.setText("Hava durumu alınamadı");
                        if (tempLabel != null) tempLabel.setText("Hata: " + e.getMessage());
                    });
                }
            }
        });
    }

    private void updateWeatherDisplay(Weather weather) {
        if (weather != null && weather.getTemperature() != 0.0) {
            if (descLabel != null) descLabel.setText(weather.getDescription());
            if (tempLabel != null) tempLabel.setText(String.format("Sıcaklık: %.1f°C", weather.getTemperature()));

            try {
                if (weatherIconImageView != null) {
                    String iconPath = WeatherIcons.iconFor(weather.getDescription(), weather.getIcon());
                    Image icon = new Image(getClass().getResourceAsStream(iconPath));
                    weatherIconImageView.setImage(icon);
                }
            } catch (Exception e) {
                // Icon yüklenemezse görmezden gel
            }
        } else {
            if (descLabel != null) descLabel.setText("Hava durumu bilgisi alınamadı");
            if (tempLabel != null) tempLabel.setText("Geçersiz konum adı");
        }
    }

    private void showAlert(String title, String message) {
        Platform.runLater(() -> {
            try {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle(title);
                alert.setHeaderText(null);
                alert.setContentText(message);
                alert.showAndWait();
            } catch (Exception e) {
                System.err.println("Alert gösterilemedi: " + title + " - " + message);
            }
        });
    }
}