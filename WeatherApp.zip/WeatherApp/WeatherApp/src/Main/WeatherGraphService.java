package Main;

import java.util.*;

public class WeatherGraphService {

    public static MyGraph<District> createWeatherGraph(String cityName) {
        MyGraph<District> weatherGraph = new MyGraph<>();
        MyLinkedList<District> districts = WeatherService.fetchDistrictWeather(cityName);

        for (District district : districts) {
            weatherGraph.addVertex(district);
        }

        connectDistricts(weatherGraph, districts);
        return weatherGraph;
    }

    private static void connectDistricts(MyGraph<District> graph, MyLinkedList<District> districts) {
        District center = null;
        for (District d : districts) {
            if (d.getName().contains("Merkez")) {
                center = d;
                break;
            }
        }

        if (center == null && !districts.isEmpty()) {
            center = districts.get(0);
        }

        for (District district : districts) {
            if (!district.equals(center)) {
                double tempDiff = Math.abs(center.getTemperature() - district.getTemperature());
                String tempLabel = String.format("%.1f°C fark", tempDiff);
                graph.addUndirectedEdge(center, district, tempDiff, tempLabel);
            }
        }

        String[] directions = {"Kuzey", "Kuzeydoğu", "Doğu", "Güneydoğu",
                "Güney", "Güneybatı", "Batı", "Kuzeybatı"};

        for (int i = 0; i < directions.length; i++) {
            District current = findDistrictByDirection(districts, directions[i]);
            District next = findDistrictByDirection(districts, directions[(i + 1) % directions.length]);

            if (current != null && next != null) {
                double tempDiff = Math.abs(current.getTemperature() - next.getTemperature());
                String label = String.format("Komşu: %.1f°C", tempDiff);
                graph.addUndirectedEdge(current, next, tempDiff, label);
            }
        }
    }

    private static District findDistrictByDirection(MyLinkedList<District> districts, String direction) {
        for (District d : districts) {
            if (d.getName().contains(direction)) {
                return d;
            }
        }
        return null;
    }

    public static District findHottestDistrict(MyGraph<District> graph) {
        MyLinkedList<District> vertices = convertSetToMyLinkedList(graph.getAllVertices());
        if (vertices.isEmpty()) return null;

        District hottest = vertices.get(0);
        for (District current : vertices) {
            if (current.getTemperature() > hottest.getTemperature()) {
                hottest = current;
            }
        }
        return hottest;
    }

    public static District findColdestDistrict(MyGraph<District> graph) {
        MyLinkedList<District> vertices = convertSetToMyLinkedList(graph.getAllVertices());
        if (vertices.isEmpty()) return null;

        District coldest = vertices.get(0);
        for (District current : vertices) {
            if (current.getTemperature() < coldest.getTemperature()) {
                coldest = current;
            }
        }
        return coldest;
    }

    public static MyLinkedList<String> findBiggestTemperatureDifferences(MyGraph<District> graph) {
        MyLinkedList<String> differences = new MyLinkedList<>();
        MyLinkedList<District> vertices = convertSetToMyLinkedList(graph.getAllVertices());

        for (District district : vertices) {
            MyLinkedList<MyGraph.Edge<District>> neighbors = graph.getNeighbors(district);

            for (MyGraph.Edge<District> edge : neighbors) {
                District neighbor = edge.getDestination();
                double tempDiff = Math.abs(district.getTemperature() - neighbor.getTemperature());

                if (tempDiff > 2.0) {
                    String info = String.format("%s ↔ %s: %.1f°C fark",
                            getShortName(district), getShortName(neighbor), tempDiff);

                    if (!differences.contains(info)) {
                        differences.add(info);
                    }
                }
            }
        }

        sortTemperatureDifferences(differences);
        return differences;
    }

    private static void sortTemperatureDifferences(MyLinkedList<String> differences) {
        for (int i = 0; i < differences.size() - 1; i++) {
            for (int j = 0; j < differences.size() - 1 - i; j++) {
                String a = differences.get(j);
                String b = differences.get(j + 1);

                double diffA = Double.parseDouble(a.split(": ")[1].replace("°C fark", ""));
                double diffB = Double.parseDouble(b.split(": ")[1].replace("°C fark", ""));

                if (diffA < diffB) {
                    differences.set(j, b);
                    differences.set(j + 1, a);
                }
            }
        }
    }

    public static MyLinkedList<District> findReachableDistricts(MyGraph<District> graph, District startDistrict) {
        return convertListToMyLinkedList(graph.breadthFirstSearch(startDistrict));
    }

    public static MyLinkedList<District> findMinTemperaturePath(MyGraph<District> graph, District start) {
        MyLinkedList<District> path = new MyLinkedList<>();
        Map<District, Double> distances = graph.dijkstra(start);

        District closest = null;
        double minDistance = Double.MAX_VALUE;

        for (Map.Entry<District, Double> entry : distances.entrySet()) {
            if (!entry.getKey().equals(start) && entry.getValue() < minDistance) {
                minDistance = entry.getValue();
                closest = entry.getKey();
            }
        }

        path.add(start);
        if (closest != null) {
            path.add(closest);
        }

        return path;
    }

    public static String getGraphStatistics(MyGraph<District> graph) {
        MyLinkedList<District> vertices = convertSetToMyLinkedList(graph.getAllVertices());
        int vertexCount = vertices.size();

        int edgeCount = 0;
        for (District vertex : vertices) {
            edgeCount += graph.getNeighbors(vertex).size();
        }
        edgeCount /= 2;

        double totalTemp = 0.0;
        double maxTemp = Double.MIN_VALUE;
        double minTemp = Double.MAX_VALUE;

        for (District district : vertices) {
            double temp = district.getTemperature();
            totalTemp += temp;

            if (temp > maxTemp) maxTemp = temp;
            if (temp < minTemp) minTemp = temp;
        }

        double avgTemp = vertexCount > 0 ? totalTemp / vertexCount : 0.0;

        return String.format(
                "📊 Graph İstatistikleri:\n" +
                        "• Bölge sayısı: %d\n" +
                        "• Bağlantı sayısı: %d\n" +
                        "• Ortalama sıcaklık: %.1f°C\n" +
                        "• En yüksek: %.1f°C\n" +
                        "• En düşük: %.1f°C\n" +
                        "• Sıcaklık aralığı: %.1f°C",
                vertexCount, edgeCount, avgTemp, maxTemp, minTemp, (maxTemp - minTemp)
        );
    }

    private static String getShortName(District district) {
        String name = district.getName();
        String[] parts = name.split(" ");
        return parts[parts.length - 1];
    }

    private static <T> MyLinkedList<T> convertSetToMyLinkedList(Set<T> set) {
        MyLinkedList<T> list = new MyLinkedList<>();
        for (T item : set) {
            list.add(item);
        }
        return list;
    }

    private static <T> MyLinkedList<T> convertListToMyLinkedList(List<T> list) {
        MyLinkedList<T> myList = new MyLinkedList<>();
        for (T item : list) {
            myList.add(item);
        }
        return myList;
    }
}